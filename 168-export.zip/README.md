# IconFlow — Studio

Maquette interactive de l’interface interne IconFlow, mise à jour le 25 octobre 2026.

## Utilisation

Servir le dossier `dist` avec un serveur HTTP statique. Pour reconstruire les moteurs 3D et d’écriture : `npm ci`, puis `npm run build`. `npm run build:editor` reconstruit seulement l’éditeur. Le dossier dist contient les bundles et toutes les ressources nécessaires. La version HTML autonome est un aperçu portable ; utiliser HTTP(S) pour bénéficier d’un stockage local stable, notamment pour les pièces jointes.

Les scripts de la page HTTP sont chargés avec `defer`, dans leur ordre de dépendance. Le premier rendu de l’interface est déclenché à `DOMContentLoaded`.

## Périmètre

Six vues : accueil, Brain, Avatar, briefs créatifs, livrables et calendrier, performance verrouillée (présentation premium uniquement, sans contrôle d’abonnement serveur). Les documents, choix d’avatars et métadonnées sont conservés en localStorage ; les pièces jointes des briefs utilisent IndexedDB. Aucun dossier client distant ni synchronisation entre appareils n’est connecté.

Les données Lashéa proviennent du prototype partagé. Les médias, scripts et références non fournis sont signalés. Les dates sont celles du prototype d’octobre 2026. Aucun dossier client, compte Meta, moteur IA ou espace de validation réel n’est connecté.

## Le Brain et ses informations

Le cerveau reste présent dans la vue Brain. Les six points ouvrent Identité, Directives, Connaissances, Produits, Références ou Avatars dans un panneau sous le modèle. Seul le panneau est actualisé : le canvas, l’orientation et la rotation continuent. Le cerveau et les informations suivent le défilement normal : aucun élément du Brain n’est fixé pendant la lecture. Une seconde sélection du même point ou la croix referme les informations ; le focus revient au point concerné.

Sur téléphone, les points constituent la navigation du Brain. Les cartes latérales répétées sont masquées, y compris pour le clavier et les lecteurs d’écran. Les boutons Pause, Recentrer, Utiliser ce Brain et les deux anciennes cartes d’action sous le cerveau sont supprimés. Nourrir le Brain reste disponible dans l’en-tête et conserve les nouvelles notes dans leur rubrique sans reconstruire la scène. Les rubriques latérales et la navigation globale se replient indépendamment, sans reconstruire le canvas. Les cartes sont en verre sombre teinté émeraude, avec des libellés seuls dans les rubriques vides. Les faux aperçus et fiches produit/avatar ont été retirés. Les notes réellement ajoutées donnent un aperçu compact ; une image facultative peut être jointe (JPG/PNG/WebP, 8 Mo maximum, miniature locale de 480 pixels). Les ajouts existants sont préservés. Le lien historique #brand reste compatible.

## Accueil et navigation

L’accueil présente le Brain 3D et un bouton « Accéder au Brain ». Les anciens compteurs, cartes de tâches et parcours du mois ont été retirés. Un lien conduit à l’espace d’écriture.

Le contrôle de la navigation est placé sur le logo. Sa flèche apparaît au survol ou au focus clavier ; elle reste repérable sur écran tactile. Le clic replie/déplie la navigation sur ordinateur et ferme le menu sur téléphone. Le nom IconFlow conserve son lien vers l’accueil lorsque la barre est dépliée.

## Avatar

La page Avatar présente une galerie de portraits avec noms discrets. La section Concepts a été retirée ; ses anciennes notes restent préservées dans les données locales. Le lien historique #angles ouvre désormais Avatar.

La cliente peut choisir plusieurs avatars, retrouver ses choix via un filtre, puis les modifier. Les sélections sont persistées dans ce navigateur, sans authentification ni synchronisation avec un autre appareil. Aucun avatar n’est présélectionné par déduction des anciennes données d’exemple. Ajout de nom et photo dans la page, remplacement de photo et suppression réversible avec restauration. JPG/PNG/WebP, 8 Mo maximum ; miniature locale de 600 pixels maximum. Aucun portrait inventé.

## Briefs mensuels et écriture libre

La vue commence par un calendrier de douze mois, pour 2026 ou 2027. L’ouverture d’un mois vide propose « Créer le brief du mois ». Une création initialise ensemble une page vidéo et une page statique. Les deux volets « Brief vidéo » et « Brief statique » se trouvent sous l’en-tête du mois. Chaque volet contient autant de pages que nécessaire, accessibles dans une liste latérale, ou horizontale sur téléphone.

Le document à droite utilise Tiptap 3.32.0 : titres, paragraphes, gras, italique, listes, citations, séparateurs, annuler/rétablir et liens. Les images, vidéos et fichiers sont insérés dans le document et stockés dans IndexedDB. Ils restent disponibles après actualisation dans le même navigateur. Les vidéos utilisent un lecteur natif. Les liens sont filtrés et ouverts avec les protections habituelles. Les pièces jointes sont limitées à 100 Mo par fichier ; un échec de stockage est signalé sans insérer un média cassé.

Le titre et le contenu sont sauvegardés automatiquement sans recréer l’éditeur pendant la saisie. Chaque page peut être renommée, dupliquée, déplacée, mise dans la corbeille et restaurée. Un changement de page pendant un import ne doit pas insérer le média dans le document suivant. Les médias ne sont pas effacés à la suppression réversible d’une page.

Les anciens brouillons et les références réellement modifiées sont repris une seule fois dans octobre 2026, avec leurs suppressions. Les six références d’exemple non modifiées ne sont pas recréées. Les anciens objets restent intacts. Le document ClickUp fourni sert de référence d’organisation (pages et document avec médias) ; son contenu GlowSmiile n’est pas importé dans Lashéa.

## Calendrier et Frame

La vue Livrables commence par une grille de douze mois, avec les années 2026 et 2027. Chaque mois ouvre ses propres notes et deux catégories : Rushs, puis Vidéos montées + statiques. Les anciennes cartes de fichiers et leurs compteurs d’exemple ont été retirés de cette vue. Aucun lien n’est prérempli.

« Ajouter le lien Frame » ouvre une saisie dans le mois. Les liens HTTPS Frame.io ou f.io sont enregistrés séparément par année/mois/catégorie. Une fois renseigné, le lien apparaît dans un bandeau « Vos rushs / créatives de [mois] », avec Ouvrir, puis une iframe. Le lien externe reste disponible si l’aperçu ne fonctionne pas. Aucune URL /embed n’est inventée et aucun statut de livraison client n’est déduit de l’existence d’un lien.

Frame.io ne documente pas d’intégration iframe garantie. L’affichage et les commentaires dépendront du lien partagé, de ses permissions et des restrictions du service. Aucun lien réel n’ayant été fourni, cet affichage distant n’a pas été vérifié. Références : https://help.frame.io/en/articles/9105232-shares-in-frame-io et https://forum.frame.io/t/embed-review-links/76 .

Les consignes du mois sont sauvegardées automatiquement, avec un bouton Enregistrer et un réessai en cas d’échec local. Les notes et liens de deux mois ou années ne se mélangent pas. Aucun téléversement vers Frame ni partage réel au client n’est proposé dans cette maquette.

## Environnement 3D

Véritable modèle anatomique 3D, matière verte mate et éclairage sculptural. Un champ d’étoiles et des voiles de nébuleuse émeraude couvrent toute la page Brain, derrière les cartes et dans les espaces entre elles. Le décor est pré-rendu dans un canvas 2D fixe, sans boucle d’animation ni second contexte WebGL. Le cerveau conserve son arc orbital discret. Rotation automatique basée sur le temps (environ 75 secondes par tour), glisser souris/tactile et orientation au clavier. La préférence système de réduction des animations est respectée. Sur téléphone, le défilement vertical de page est autorisé sur le canvas.

Le modèle principal `brain-anatomical-lite.glb` contient 30 000 triangles pour 543 052 octets. Le modèle `brain-anatomical-software.glb`, destiné au rendu logiciel, contient 16 000 triangles pour 291 580 octets. Les deux GLB sont servis depuis la même origine, sans Draco ni décodeur externe. Ils conservent les cinq structures, l’orientation et la normalisation du modèle source, avec normales lissées. Chaque modèle chargé et analysé est mis en cache pour la session ; les nouvelles vues partagent ses buffers de géométrie et clonent ses transformations, sans recommencer le chargement à chaque navigation.

L’éclairage WebGL ne génère plus d’environnement PMREM. Le DPR est plafonné à 1,5 sur ordinateur et à 1,25 sur appareil tactile ; le rendu logiciel utilise un framebuffer de 1 000 × 700 pixels maximum, limité à 600 000 pixels, puis conserve la taille CSS de la vue. Les flous d’arrière-plan des cartes sont désactivés seulement dans ce mode pour éviter leur recalcul à chaque image. Les ombres WebGL utilisent une carte de 512 × 512 pixels, calculée une fois par scène, et sont désactivées avec un pointeur tactile. L’animation est suspendue hors écran et en onglet masqué. Les ressources GPU propres à la vue sont libérées à sa fermeture ; les modèles analysés restent en cache pour la session.

Un aperçu est visible immédiatement pendant le chargement, puis laisse place à la première image rendue. Si l’accélération graphique est indisponible, si WebGL ne peut pas démarrer ou si son contexte est perdu, le Brain utilise un véritable rendu 3D logiciel sur Canvas 2D : la géométrie reste projetée et éclairée, avec interpolation par pixel et tampon de profondeur, rotation et contrôle de la caméra. Un seul transfert de pixels vers Canvas est effectué par image, sans milliers de gradients Canvas. Un échec de téléchargement conserve l’aperçu et propose « Réessayer ». Aucun service de rendu externe.

## Sources et licences

Source fonctionnelle : https://claude.ai/artifact/H63uxZQnWRecLsALRETwpy
Inspiration : captures Craft, cerveau et structure latérale fournies par l’utilisateur. Logo IconFlow blanc fourni le 25 octobre, conservé sans modification de l’image. Les accents de marque restent verts.

Modèle : Brain for Blender, Anderson Winkler (Brainder.org), dérivé de surfaces IRM ; cinq maillages. Les versions d’affichage de 30 000 et 16 000 triangles sont calculées directement depuis les OBJ sources. Le modèle complet `brain-anatomical.glb` de 103 000 triangles et 2 473 836 octets est conservé sans modification, avec les ressources et notices d’origine. Attribution, tailles et adaptations : `dist/assets/brain-ATTRIBUTION.md`. Les modèles adaptés restent sous CC BY-SA 3.0 ; téléchargement accessible dans les crédits de la maquette.
Moteur : Three.js 0.180.0, licence MIT dans `dist/assets/THREE-LICENSE.txt`. Éditeur : Tiptap 3.32.0 / ProseMirror, licences MIT dans les dépendances et dans `dist/assets/EDITOR-LICENSES.txt`.

## Vérification de cette version

Compilation, syntaxe JS et diff vérifiés. Les six rubriques s’ouvrent sous un canvas unique dont le compteur d’images continue. Rotation conservée, fermeture et retour du focus vérifiés. Vue à 390 pixels inspectée : cartes dupliquées absentes, cerveau et titre du panneau défilent normalement. Barres repliables, fond global et ajout de note avec aperçu compact vérifiés. Performance ne contient que le cadenas et le message premium. Contrôles supprimés absents du DOM.

Optimisation du Brain : les deux GLB ont été ouverts avec le véritable `GLTFLoader` de Three.js ; noms des cinq meshes, indices Uint16, positions/normales Float32, normales unitaires et nombres de triangles vérifiés. Le SHA-256 du modèle complet est inchangé. Une comparaison visuelle sous trois angles confirme la conservation de la silhouette et des principaux sillons, avec réduction des détails les plus fins.

Vérification dans Chrome avec WebGL désactivé : apparition du modèle, rotation automatique, glisser, clavier, ouverture des informations et réutilisation du cache. Vérification dans le navigateur intégré avec WebGL : rendu normal et bascule vers le rendu logiciel après perte volontaire du contexte graphique. Le harness de cycle de vie couvre aussi les téléchargements tardifs, les échecs réseau/réessais et la libération des ressources. Les mesures locales ne constituent pas une garantie de délai sur réseau distant.


Refonte mensuelle : syntaxe et compilation validées. Vérification navigateur : calendrier, création d’un mois avec deux volets, titre/texte, sous-titre/gras/lien, import d’image persistante après rechargement, duplication/suppression/restauration et écriture après aller-retour Avatar/Briefs. Choix d’avatar conservé après rechargement et restauration. Vue mobile à 390 pixels inspectée.

Tests VM du modèle mensuel : migration idempotente sans réintroduire les exemples, copie indépendante, ordre, annulation, erreurs de sauvegarde, isolation des callbacks détruits et cycle hashchange/BFCache. Tests Tiptap avec DOM et IndexedDB simulés : média image/vidéo/fichier, remontage, import interrompu, quota, retrait/annulation, collage et filtrage des liens. Le décodage d’une vidéo réelle n’a pas été vérifié dans le navigateur.

## Supabase — projet de test

Deux modes sont séparés : la démo locale conserve les clés existantes du navigateur ; le mode connecté n'utilise aucune donnée locale de remplacement. L'écran de connexion est l'état par défaut, même sur une route directe. Le SDK v2 est importé en ESM depuis le CDN demandé. Seule la clé publishable publique figure dans le front.

`auth-gate.js` vérifie la session avec `auth.getUser()`, puis lit uniquement `profiles(id, role, client_id)` pour cet utilisateur. Un profil absent, un rôle non reconnu ou un client non affecté restent sans accès aux données. Les profils et rôles ne sont jamais modifiés depuis l'interface. Les droits réels restent les politiques RLS existantes de Supabase : aucune politique ni clé privilégiée n'est installée par ce raccordement.

`supabase-store.js` centralise les requêtes. Pour un compte client, `clients` est filtrée sur `id = profiles.client_id` et les quatre tables `briefs`, `avatars`, `livrables`, `validations` sur `client_id`. Une demande visant un autre client est refusée avant l'appel réseau. Pour l'agence, la liste de clients accessible à sa session est chargée, puis les données sont demandées séparément par client. Chaque liste est limitée à 200 lignes, avec mention visible si cette limite est atteinte. Aucun contournement ni appel à l'API d'administration Auth.

Les champs d'affichage reconnus sont `name/nom/title/titre/brand_name`, `status/statut`, `month/mois/period/created_at`, `content/body/script/description/texte` et, pour les liens, `frame_url/lien_frame/url/photo_url/image_url/avatar_url`. Une table absente ou un format incompatible produit un état vide explicite. Le Brain n'a pas de table définie dans le périmètre fourni et reste non raccordé en mode connecté. L'archivage serveur exige `clients.archived_at`; aucune suppression définitive n'est proposée. Les changements de statut sont soumis à la validation du schéma et aux politiques RLS.

Les réponses connectées restent en mémoire et sont vidées à la déconnexion et au changement de session. Les réponses tardives d'une session précédente sont ignorées. Les recherches récentes connectées sont distinctes de celles de la démo. Les identifiants de connexion ne sont jamais enregistrés par le formulaire ; le SDK gère sa session dans sa propre clé de stockage.

Validation automatisée : `node --test tests/supabase-store.test.mjs` couvre les profils invalides, les filtres par client, le refus des clients étrangers avant requête, les identifiants numériques, le périmètre des mises à jour et les erreurs de schéma/connexion. Les parcours visuels des rôles sont testés avec des réponses simulées isolées ; ces fixtures ne sont pas publiées. Une validation de bout en bout sur le projet réel nécessite des comptes de test existants pour chacun des deux rôles. Aucun compte ni email n'est créé par les tests.

### Écrans métier connectés — version suivante

`connected-studio.js` réemploie les classes/mises en page des écrans d’origine sans lire ni modifier leur état local : accueil et Brain 3D de l’accueil, calendriers annuels des briefs et livrables, rail de pages et document de brief, galerie d’avatars, document Brain et rubriques. Les cinq tables métier sont lues exclusivement par `client_id`, y compris `brand_dossiers`.

Lecture : titres, mois, types et statuts des briefs ; intégralité de `briefs.content` JSONB (concept, transcription/hooks/corps/CTA, acting/plans quand ces clés existent, autres clés conservées et affichées) ; `avatars.name/preview_url/chosen` ; `livrables.month/kind/title/status/file_url/duration_sec` ; historique `validations` associé par `brief_id` ou `item_ref` égal à l’id du livrable ; `brand_dossiers.data` avec promesse, personas, ton, concurrents. Un type/mois absent n’est pas inventé. Aucun dossier d’exemple ne remplit un écran vide.

Écriture agence : modification des textes existants dans `briefs.content` et `brand_dossiers.data`, update de la ligne filtré par client et id disponible, sans modifier les autres clés/types du JSON. Une condition sur l’ancien JSON empêche l’écrasement silencieux d’une modification concurrente. La confirmation n’apparaît qu’après réponse réussie avec une ligne renvoyée par Supabase ; les erreurs PostgREST restent visibles et le formulaire garde son texte. Création et archivage réversible des briefs raccordés côté agence (voir ci-dessous). Création de dossier Brain, ajout d’avatar, upload/photo ou modification de lien non raccordés ; aucune suppression définitive de brief.

Gates raccordées : seul le client propriétaire peut modifier `avatars.chosen` ; agence `livrables.status=en_controle` vers `attente_client` ; client uniquement `attente_client` vers `valide` ou `correction`. Les updates vérifient également la valeur précédente. L’agence ne valide jamais à la place du client. Les écritures dans `validations` passent uniquement par les actions métier contrôlées, jamais par un bouton générique d’édition d’historique. Gates briefs raccordées sur le schéma confirmé : agence redaction → attente_ibra ; vidéo attente_ibra → attente_client par Ibra, puis attente_client → valide par le client ; statique attente_ibra → valide par Ibra seul. Le client consulte les statiques sans bouton de validation. Chaque approbation agence est insérée dans validations (script + brief_id), puis le brief est mis à jour avec condition sur statut/kind/contenu précédents et validated_by/validated_at. Un refus d’INSERT bloque la transition. Les décisions client des livrables utilisent item_kind rushs ou crea avant le changement de statut. Pour ces anciens chemins agence/livrables, le trigger ne faisant que contrôler, les deux requêtes ne sont pas atomiques : échec partiel affiché explicitement, reprise sans nouvel INSERT dans cet onglet tant qu’il n’est pas rechargé. La reprise repose sur un journal en mémoire séparé par compte ; aucun secret ni nouvelle table/RPC. Le serveur/RLS reste l’autorité ; aucune politique ni fonction serveur créée/modifiée.

Validation : `node --test tests/*.test.mjs` (38 tests), contrôles de syntaxe. Banc navigateur isolé non publié : rendu desktop et iframe 390px, documents brief/Brain modifiés puis relus après reload sur SDK simulé, choix d’avatar client persistant sur ce banc, absence d’action client sur un livrable `en_controle`, contrôle Ibra vers attente client. Les fixtures ont été retirées de dist avant publication. Ce banc ne prouve pas une écriture acceptée par le projet Supabase réel ; aucun compte valide n’était disponible. Schéma confirmé : vidéo {concept, transcription:{hooks[],corps,ctas[]}, acting} ; statique {reference,angle,overlay}, kind=statique ; Brain {promesse,personas:[{nom,resume}],ton,concurrents[]}. Les libellés et l’édition reprennent ces champs. Les updates Brain renseignent updated_by/updated_at. Toute modification de contenu d’un brief soumis/validé le remet en redaction avec remise à zéro de validated_by/validated_at, pour éviter d’approuver implicitement un nouveau texte.

Vérification complémentaire des gates avec le schéma exact : banc isolé desktop, validation vidéo Ibra → attente_client puis client → valide ; mobile iframe 390px, lecture des champs statiques et zéro bouton de validation client, absence de débordement horizontal. Banc retiré avant publication. Les tests couvrent le refus du trigger, l’échec partiel/reprise et la remise en rédaction après édition. Aucune écriture dans le projet Supabase réel n’a été testée.

### Ouverture des espaces clients

Le sélecteur d’espace a été retiré du HTML, des styles et des gestionnaires en démo comme en connecté. Le seul contrôle qui change explicitement de client est « Ouvrir l’espace » dans la liste `#agency/admin`. Les fiches et aperçus Admin ne changent pas le client courant ; le lien de retour conserve le dernier espace ouvert. Aucun changement d’Auth, de rôles, de RLS ni des routes métier. Le nom du client reste affiché en contexte, y compris dans le breadcrumb mobile. Les données/états nécessaires à l’espace courant et à son stockage restent conservés ; aucun état de picker ne subsiste.

### Décision client des scripts : RPC atomique

Après la modale Annuler/Confirmer, le compte client appelle uniquement `supabase.rpc('client_decide_script', {p_brief_id, p_decision, p_comment:null})`. L’authentification passe par le SDK/session existant ; aucun header privilégié ni modification Auth/RLS. Le serveur calcule item_ref, decided_by et les métadonnées et effectue la décision + transition atomiquement. Aucune déduction de version, aucun INSERT validations ni UPDATE briefs de secours dans ce chemin client. Le flux direct restant pour l’approbation agence est séparé et refuse le rôle client ; les flux avatars/rushs/crea/livrables sont inchangés.

Succès RPC : le retour `{id,item_ref,decision}` identifie une décision, jamais le brief. L’app relit le brief exclusivement par son id et client_id. Validation : affichage Validé et bouton désactivé ; correction : affichage En rédaction. Si la relecture échoue après une RPC confirmée, l’UI conserve le statut garanti par le contrat serveur et signale que les détails sont à recharger ; elle n’invente pas validated_by/validated_at et ne tente aucune écriture directe. Les protections en vol restent actives. L’unicité et l’atomicité de la décision sont assurées par la fonction serveur existante.

Messages français par erreur P0001 : not_authenticated, not_a_client, brief_not_found, wrong_client, static_brief_ibra_only, wrong_state:statut, bad_decision, already_decided. Les deux derniers cas d’état/doublon relisent le brief lorsque possible ; already_decided désactive toute nouvelle confirmation pour la version affichée. Une erreur RPC ne déclenche aucun mécanisme de reprise INSERT/UPDATE séparé. Les erreurs partielles restent pertinentes uniquement pour les autres chemins existants.

Vérification : 38 tests automatisés ; assertions d’appel RPC exact avec p_comment:null, absence d’INSERT/UPDATE direct côté client, corrections, huit messages d’erreur, concurrence, relecture indisponible, rôle client refusé par le chemin agence. Banc navigateur isolé desktop/mobile 390px : confirmation, validation, correction, already_decided en français et confirmation désactivée ; fixtures sans méthodes insert/update pour ce client et sans label de version local. Les fixtures sont retirées avant publication. Pas de test réel du projet Supabase avec un compte client valide.


### Studio connecté : historique, transcription et pages de briefs

Le détail vidéo client affiche chaque décision dans une ligne dédiée (label de version, décision lisible, date locale française), classée par created_at croissant ; à date égale ou absente l’ordre des entrées est stable. L’historique hérite de la couleur du texte du document pour un contraste lisible. La transcription et les champs éditables présentent Hooks → Corps → CTA indépendamment de l’ordre des clés JSON, sans modifier le JSON source ni les indices d’enregistrement. Les trois parties du brief restent distinctes.

Agence : « Ajouter une page » dans un mois/volet ouvre un formulaire titre/type. INSERT briefs avec client_id courant, month=YYYY-MM-01, kind=video/statique, title, status=redaction, source=agence et content vide selon le schéma communiqué (hooks/ctas initialisés par une entrée vide pour rester éditables). Le client ne dispose d’aucun bouton ni message de création non raccordée. Le repository refuse ces opérations pour un client avant toute requête.

Corbeille agence : confirmation puis UPDATE briefs status=archived filtré par id/client_id/statut courant ; contenu conservé et aucune suppression définitive. Les archives sont exclues des listes actives, compteurs et résultats de recherche. Corbeille du mois avec restauration ou Annuler après archivage ; UPDATE status=redaction, validated_by/validated_at=NULL, afin de reprendre le contrôle du contenu. Les erreurs PostgREST restent sous le formulaire/la confirmation ; aucun état local n’annonce un succès en cas de refus de l’écriture.

Mobile connecté ≤720px : tiroir scrollable, largeur limitée au viewport, ouverture/fermeture et aria-expanded synchronisés, retour du focus, fermeture Échap/clic dehors/lien, focus clavier contenu dans le menu ouvert. Cibles tactiles de 44px. CSS limité au mode connecté ; apparence desktop et branding conservés.

Vérification : 44 tests automatisés. Banc navigateur isolé : vidéo créée puis relue après reload ; archivage puis corbeille relue après reload et restauration ; création statique sur viewport 390px ; erreur RLS simulée visible sans faux succès ; vue cliente sans création, histoire ordonnée/contrastée, Hooks/Corps/CTA, menu ouvrir/Échap et aucun débordement horizontal à 390px. Fixtures retirées avant publication. Les écritures du projet Supabase réel n’ont pas été validées avec un compte agence. La fonction RPC client des scripts et le chemin livrables ont été vérifiés inchangés par comparaison de source.
