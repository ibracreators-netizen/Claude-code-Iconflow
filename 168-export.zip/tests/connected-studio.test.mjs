import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import * as Store from '../dist/supabase-store.js';
function fixture(role='agency'){
  const dialog={html:'',open:false,output:{textContent:'',isConnected:true}},sandbox={window:{},icon:()=>'',Date,URL,structuredClone,location:{},console,document:{querySelectorAll:()=>[],querySelector:selector=>selector==='#studio-decision-feedback'?dialog.output:null},showDialog:(title,subtitle,html)=>{dialog.html=html;dialog.open=true;},closeDialog:()=>{dialog.open=false;}};
  vm.runInNewContext(fs.readFileSync(new URL('../dist/connected-studio.js',import.meta.url),'utf8'),sandbox);
  const data=Object.fromEntries(Store.DATA_TABLES.map(t=>[t,{rows:[],error:null}]));
  data.briefs.rows=[{id:'b',client_id:'c',kind:'video',month:'2026-10-01',title:'Brief API',content:{concept:'Concept API',transcription:{hooks:['Hook API'],corps:'Corps API',ctas:['CTA API']},acting:'Acting API',plans:['Plan API']}}];
  data.validations.rows=[{brief_id:'b',item_kind:'script',item_ref:'script-v2',decision:'valide',decided_by:'agency',created_at:'2026-10-26T00:00:00Z'}];
  data.avatars.rows=[{id:'a',client_id:'c',name:'Avatar API',preview_url:'https://example.test/avatar.png',chosen:true}];
  data.livrables.rows=[{id:'d',client_id:'c',month:'2026-10-01',title:'Livrable API',kind:'video',status:'en_controle'}];
  data.brand_dossiers.rows=[{id:'bd',client_id:'c',data:{promesse:'Promesse API',ton:'Ton API',personas:['Persona API'],concurrents:['Concurrent API']}}];
  const ctx={clientId:'c',name:'Marque API',role,Store,data,issue:()=>'',repaint(){},refresh(){}};
  return {ui:sandbox.window.IconFlowConnectedStudio,ctx,dialog};
}
test('connected pages use original studio layouts with remote data only',()=>{
  const {ui,ctx}=fixture();
  for(const [page,css,text] of [['overview','studio-home','Marque API'],['briefs','mb-month-grid','2'],['avatars','av-gallery','Avatar API'],['deliverables','delivery-month-grid','Livrables'],['brain','brain-layout','Promesse API']]){
    const html=ui.render(page,ctx);assert(html.includes(css));if(page!=='briefs')assert(html.includes(text));assert(!/Lashéa|Inès|Maya|Brain non raccordé/.test(html));
  }
  const client=fixture('client');assert(client.ui.render('avatars',client.ctx).includes('data-studio-action="choose-avatar"'));assert(!ui.render('avatars',ctx).includes('data-studio-action="choose-avatar"'));
});
test('brief deep result opens the month document and displays all three parts',()=>{
  const {ui,ctx}=fixture();ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);
  const html=ui.render('briefs',ctx);for(const value of ['Concept API','Hook API','Corps API','CTA API','Acting API','Plan API','Comprendre le concept','Transcription','Acting et plans'])assert(html.includes(value));
  assert(html.includes('Historique des décisions'));assert(html.includes('data-studio-action="new-brief"'));
});
test('deliverable controls differ by role and gate, without validating early',()=>{
  for(const role of ['agency','client']){
    const {ui,ctx}=fixture(role);ui.render('deliverables',ctx);ui.open('livrables',ctx.data.livrables.rows[0]);
    const html=ui.render('deliverables',ctx);assert.equal(html.includes('data-next="attente_client"'),role==='agency');assert(!html.includes('data-next="valide"'));
    ctx.data.livrables.rows[0].status='attente_client';const waiting=ui.render('deliverables',ctx);assert.equal(waiting.includes('data-next="valide"'),role==='client');assert.equal(waiting.includes('data-next="correction"'),role==='client');
  }
});
test('empty connected pages never fall back to local examples',()=>{
  const {ui,ctx}=fixture();for(const result of Object.values(ctx.data))result.rows=[];
  for(const page of ['brain','avatars','briefs','deliverables']){const html=ui.render(page,ctx);assert(!/Lashéa|Inès|Maya/.test(html));assert(/Aucun|Aucune|attend/.test(html));}
});

test('exact schema fields render French labels and role-specific brief actions',()=>{
  for(const role of ['agency','client']){
    const {ui,ctx}=fixture(role);const row=ctx.data.briefs.rows[0];
    row.status='attente_ibra';ui.render('briefs',ctx);ui.open('briefs',row);let html=ui.render('briefs',ctx);
    assert.equal(html.includes('data-studio-action="brief-transition"'),role==='agency');assert(html.includes('CTA API'));assert(!html.includes('>ctas<'));
    row.status='attente_client';html=ui.render('briefs',ctx);assert.equal(html.includes('data-studio-action="brief-transition"'),role==='client');
    row.kind='statique';row.content={reference:'Image API',angle:'Angle API',overlay:'Texte API'};row.status='attente_ibra';ui.open('briefs',row);html=ui.render('briefs',ctx);
    assert.equal(html.includes('data-studio-action="brief-transition"'),role==='agency');assert(html.includes('Texte à l’écran'));assert(html.includes('Image API'));
  }
});

test('validation requires confirmation and cancelling sends no write',async()=>{
  const {ui,ctx,dialog}=fixture('client');ctx.data.briefs.rows[0].status='attente_client';let writes=0;ctx.write=async()=>{writes++;return {};};
  ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);ui.render('briefs',ctx);
  await ui.click({dataset:{studioAction:'brief-transition',id:'b',next:'valide'}});assert.equal(writes,0);assert(dialog.open);assert(dialog.html.includes('Annuler'));assert(dialog.html.includes('Confirmer'));
  await ui.click({dataset:{studioAction:'cancel-decision'}});assert.equal(writes,0);assert(!dialog.open);
});
test('a French RPC error remains visible after a same-account rerender',async()=>{
  const {ui,ctx,dialog}=fixture('client');ctx.data.briefs.rows[0].status='attente_client';let finish;ctx.write=()=>new Promise(resolve=>{finish=resolve;});
  ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);ui.render('briefs',ctx);
  await ui.click({dataset:{studioAction:'brief-transition',id:'b',next:'valide'}});const pending=ui.click({dataset:{studioAction:'confirm-decision'}});
  ui.render('briefs',{...ctx});finish({data:null,error:{code:'P0001',message:'wrong_state: redaction'},userMessage:'Ce brief n’est pas en attente de ta décision.'});await pending;
  const html=ui.render('briefs',{...ctx});assert(html.includes('Ce brief n’est pas en attente de ta décision.'));assert(dialog.output.textContent.includes('Ce brief n’est pas en attente de ta décision.'));assert(!dialog.output.textContent.includes('Décision enregistrée, mais'));
});
test('successful validation immediately updates the status and disables duplicate decisions',async()=>{
  const {ui,ctx}=fixture('client');const row=ctx.data.briefs.rows[0];row.status='attente_client';let writes=0;
  ctx.write=async(action,old,next,ref)=>{writes++;assert.equal(ref,null);return {data:{...old,status:'valide',validated_by:'client',validated_at:'2026-10-26T00:00:00Z'},error:null};};
  ctx.applyRow=(table,next)=>{ctx.data[table].rows=[next];};
  ui.render('briefs',ctx);ui.open('briefs',row);ui.render('briefs',ctx);await ui.click({dataset:{studioAction:'brief-transition',id:'b',next:'valide'}});await ui.click({dataset:{studioAction:'confirm-decision'}});
  const html=ui.render('briefs',ctx);assert(html.includes('aria-disabled="true">Validé</span>'));assert(!html.includes('data-studio-action="brief-transition"'));await ui.click({dataset:{studioAction:'brief-transition',id:'b',next:'valide'}});assert.equal(writes,1);
});

test('client confirmation works without a browser-side version label and already_decided blocks retry',async()=>{
  const {ui,ctx,dialog}=fixture('client');ctx.data.validations.rows=[];const row=ctx.data.briefs.rows[0];row.status='attente_client';let writes=0;
  ctx.write=async()=>{writes++;return {data:null,error:{code:'P0001',message:'already_decided'},userMessage:'Tu as déjà enregistré une décision pour cette version.',terminal:true};};
  ui.render('briefs',ctx);ui.open('briefs',row);let html=ui.render('briefs',ctx);assert(html.includes('data-studio-action="brief-transition"'));await ui.click({dataset:{studioAction:'brief-transition',id:'b',next:'valide'}});assert.equal(writes,0);assert(dialog.open);await ui.click({dataset:{studioAction:'confirm-decision'}});
  html=ui.render('briefs',ctx);assert(html.includes('Décision déjà enregistrée'));assert(!html.includes('data-studio-action="brief-transition"'));await ui.click({dataset:{studioAction:'confirm-decision'}});assert.equal(writes,1);
});

test('client video history has readable dated rows in chronological order without pills',()=>{
  const {ui,ctx}=fixture('client');ctx.data.validations.rows=[
    {brief_id:'b',item_ref:'script-v3',decision:'valide',created_at:'2026-10-23T10:00:00Z'},
    {brief_id:'b',item_ref:'script-v1',decision:'correction',created_at:'2026-10-21T10:00:00Z'},
    {brief_id:'b',item_ref:'script-v2',decision:'valide',created_at:'2026-10-22T10:00:00Z'}];
  ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);const html=ui.render('briefs',ctx);
  assert.equal((html.match(/class="decision-history-row"/g)||[]).length,3);assert(html.indexOf('<strong>script-v1')<html.indexOf('<strong>script-v2'));assert(html.indexOf('<strong>script-v2')<html.indexOf('<strong>script-v3'));assert(html.includes('Correction demandée'));assert(html.includes('datetime="2026-10-21T10:00:00.000Z"'));
});
test('transcription displays Hooks then Corps then CTA regardless of JSON key order',()=>{
  const {ui,ctx}=fixture('client');const transcription={corps:'CORPS_FIRST',ctas:['CTA_SECOND'],hooks:['HOOK_LAST']};ctx.data.briefs.rows[0].content.transcription=transcription;
  ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);const html=ui.render('briefs',ctx);
  assert(html.indexOf('HOOK_LAST')<html.indexOf('CORPS_FIRST'));assert(html.indexOf('CORPS_FIRST')<html.indexOf('CTA_SECOND'));assert.deepEqual(Object.keys(transcription),['corps','ctas','hooks']);
});
test('client never gets brief creation controls; agency can create or view persisted trash',async()=>{
  for(const role of ['agency','client']){
    const {ui,ctx,dialog}=fixture(role);ui.render('briefs',ctx);ui.open('briefs',ctx.data.briefs.rows[0]);let html=ui.render('briefs',ctx);
    assert.equal(html.includes('data-studio-action="new-brief"'),role==='agency');if(role==='client'){assert(!html.includes('Ajouter une page'));assert(!html.includes('Création non raccordée'));}
    await ui.click({dataset:{studioAction:'new-brief'}});assert.equal(dialog.open,role==='agency');
    if(role==='agency'){assert(dialog.html.includes('studio-brief-create-form'));assert(dialog.html.includes('Titre du brief'));await ui.click({dataset:{studioAction:'cancel-brief-create'}});}
    ctx.data.briefs.rows[0].status='archived';html=ui.render('briefs',ctx);assert(!html.includes('Brief API'));if(role==='agency'){await ui.click({dataset:{studioAction:'brief-trash'}});html=ui.render('briefs',ctx);assert(html.includes('Brief API'));assert(html.includes('Restaurer'));}
  }
});
test('client history distinguishes real profile roles on the same version and validated is a badge',()=>{
  const {ui,ctx}=fixture('client');const row=ctx.data.briefs.rows[0];row.status='valide';
  ctx.data.decisionAuthors={rows:[{id:'a',role:'agency'},{id:'c',role:'client'}]};
  ctx.data.validations.rows=['a','c','unreadable'].map((id,i)=>({brief_id:'b',item_ref:'script-v2',decision:'valide',decided_by:id,created_at:`2026-10-2${i+1}T00:00:00Z`}));
  ui.render('briefs',ctx);ui.open('briefs',row);const html=ui.render('briefs',ctx);
  assert(html.includes('decision-author">Auteur : Agence'));assert(html.includes('decision-author">Auteur : Client'));assert(html.includes('Auteur non disponible'));
  assert.equal((html.match(/class="decision-history-row"/g)||[]).length,3);assert(html.includes('aria-disabled="true">Validé</span>'));assert(!html.includes('data-studio-action="brief-transition"'));
  for(const page of ['overview','brain','avatars','briefs','deliverables'])assert(!/Supabase|non raccordé|exemple local/.test(ui.render(page,ctx)));
});

test('own decision author remains known when other profiles are hidden by RLS',()=>{
  const {ui,ctx}=fixture('client');ctx.accountId='my-client-id';ctx.data.decisionAuthors={rows:[],error:{code:'42501'}};
  ctx.data.validations.rows=[{brief_id:'b',item_ref:'script-v2',decision:'valide',decided_by:'agency-hidden'}, {brief_id:'b',item_ref:'script-v2',decision:'valide',decided_by:'my-client-id'}];
  let html=ui.render('overview',ctx);assert(html.includes('Auteur : Client'));assert(html.includes('Auteur non disponible'));assert(!html.includes('Auteur : Agence'));
  ui.open('briefs',ctx.data.briefs.rows[0]);html=ui.render('briefs',ctx);assert(html.includes('Auteur : Client'));assert(html.includes('Auteur non disponible'));
});
test('business-facing templates contain no provider names',()=>{
  for(const name of ['connected-studio.js','settings.js'])assert(!/Supabase/.test(fs.readFileSync(new URL('../dist/'+name,import.meta.url),'utf8')));
  const gate=fs.readFileSync(new URL('../dist/auth-gate.js',import.meta.url),'utf8');assert(!gate.includes("Projet de démonstration · données fictives"));assert(!gate.includes('data-access-action="demo"'));assert(!/données Supabase|Enregistrer dans Supabase|session Supabase/.test(gate));
});

test('Brain data errors show a clear alert, no decorative image, 3D viewport or misleading empty state',()=>{
 const {ui,ctx}=fixture();ctx.data.brand_dossiers={rows:[],error:{code:'READ_TIMEOUT'}};
 const html=ui.render('brain',ctx);assert(html.includes('role="alert"'));assert(html.includes('Impossible de charger les données du Brain'));assert(html.includes('Réessayer le chargement'));
 for(const text of ['data-brain-viewport','brain-loading','brain-visual.svg','Le Brain attend ses premières informations'])assert(!html.includes(text));
});
test('Brain data loading is distinct from visual loading and real brand fields remain readable when available',()=>{
 const {ui,ctx}=fixture();const real=ctx.data.brand_dossiers;ctx.data.brand_dossiers={rows:[],error:null,loading:true};
 const loading=ui.render('brain',ctx);assert(loading.includes('Chargement des informations du Brain'));assert(!loading.includes('data-brain-viewport'));assert(!loading.includes('prend forme'));
 ctx.data.brand_dossiers=real;const html=ui.render('brain',ctx);for(const text of ['Promesse API','Persona API','Ton API','Concurrent API','data-brain-viewport'])assert(html.includes(text));
});
