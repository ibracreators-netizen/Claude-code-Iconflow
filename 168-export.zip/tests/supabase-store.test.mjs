import test from 'node:test';
import assert from 'node:assert/strict';
import {ScopedRepository,checkedProfile,authError,recordTitle,recordStatus,recordStatusCode,supportedRecord,recordLink,clientSlug,clientValues,postgrestMessage,documentLeaves,patchDocument,recordMonth,briefKind,allowedDeliveryTransition,briefTransition,scriptVersion,clientScriptError,newBriefValues} from '../dist/supabase-store.js';
function fakeSDK(records={}){
  const requests=[];
  return {requests,from(table){const request={table,filters:[],operation:'select'};requests.push(request);const query={select(){return query;},eq(key,value){request.filters.push([key,value]);return query;},limit(){return Promise.resolve({data:records[table]||[],error:null});},update(values){request.operation='update';request.values=values;return query;},insert(values){request.operation='insert';request.values=values;return query;},single(){return Promise.resolve({data:records[table]?.[0]||(request.operation==='insert'?{id:'event-id',created_at:'2026-10-26T00:00:00Z',...request.values}:request.operation==='update'?{id:'updated-id',...request.values}:null),error:null});}};return query;}};
}
const client=()=>checkedProfile({id:'user-A',role:'client',client_id:'client-A'},'user-A');
test('invalid or incomplete profiles never gain access',()=>{
  for(const row of [null,{id:'other',role:'agency'},{id:'user-A',role:'admin'},{id:'user-A',role:'client',client_id:null}])assert.throws(()=>checkedProfile(row,'user-A'));
  assert(Object.isFrozen(client()));
});
test('all five client data queries carry the assigned client_id',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,client());
  for(const table of ['briefs','avatars','livrables','validations','brand_dossiers'])await repo.table(table,'client-A');
  assert.equal(sdk.requests.length,5);
  for(const request of sdk.requests)assert.deepEqual(request.filters,[['client_id','client-A']]);
});
test('foreign clients and unsupported tables are refused before any request',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,client());
  await assert.rejects(repo.table('briefs','client-B'));
  await assert.rejects(repo.table('profiles','client-A'));
  await assert.rejects(repo.validation('v1','client-B','approved'));
  await assert.rejects(repo.createClient({name:'Not permitted'}));
  await assert.rejects(repo.updateClient('client-B',{name:'Not permitted'}));
  assert.equal(sdk.requests.length,0);
});
test('client metadata query requests only its own client',async()=>{
  const sdk=fakeSDK({clients:[{id:'client-A',name:'Test'}]}),repo=new ScopedRepository(sdk,client());
  const result=await repo.clients();assert.equal(result.rows.length,1);
  assert.deepEqual(sdk.requests[0].filters,[['id','client-A']]);
});
test('unexpected rows from another client are discarded',async()=>{
  const sdk=fakeSDK({briefs:[{id:'b',client_id:'client-B',title:'Foreign'}],clients:[{id:'client-B',name:'Foreign'}]}),repo=new ScopedRepository(sdk,client());
  assert.deepEqual((await repo.table('briefs','client-A')).rows,[]);
  assert.deepEqual((await repo.clients()).rows,[]);
});
test('agency sees clients but data requests remain individually scoped',async()=>{
  const sdk=fakeSDK(),profile=checkedProfile({id:'agency',role:'agency',client_id:null},'agency'),repo=new ScopedRepository(sdk,profile);
  await repo.clients();await repo.table('briefs','client-A');await repo.table('briefs','client-B');
  assert.deepEqual(sdk.requests[0].filters,[]);assert.deepEqual(sdk.requests[1].filters,[['client_id','client-A']]);assert.deepEqual(sdk.requests[2].filters,[['client_id','client-B']]);
});
test('validation history cannot be edited through an ungated action',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,client());await assert.rejects(repo.validation('v','client-A','approved'));assert.equal(sdk.requests.length,0);
});
test('unavailable table remains empty and keeps the Supabase error',async()=>{
  const error={code:'PGRST205'};const sdk={from(){return {select(){return this;},eq(){return this;},limit(){return Promise.resolve({data:null,error});}};}};
  const result=await new ScopedRepository(sdk,client()).table('avatars','client-A');assert.deepEqual(result.rows,[]);assert.equal(result.error,error);
});
test('sign-in errors are clear and do not expose backend details',()=>{
  assert.equal(authError({code:'invalid_credentials',status:400}),'Email ou mot de passe incorrect.');
  assert.match(authError({code:'email_not_confirmed',status:400}),/confirmée/);assert.match(authError({status:429}),/Trop de tentatives/);
});
test('numeric client identifiers stay scoped rather than falling back to all clients',async()=>{
  const profile=checkedProfile({id:'user-A',role:'client',client_id:12},'user-A');
  const sdk=fakeSDK({briefs:[{id:1,client_id:12,title:'Owned'}]});
  const result=await new ScopedRepository(sdk,profile).table('briefs','12');
  assert.equal(result.rows.length,1);assert.deepEqual(sdk.requests[0].filters,[['client_id','12']]);
});

test('database agency role is recognized and the obsolete French value is refused',()=>{
  assert.equal(checkedProfile({id:'a',role:'agency'},'a').role,'agency');
  assert.throws(()=>checkedProfile({id:'a',role:'agence'},'a'));
});
test('real connected rows display without changing their source data',()=>{
  const delivery={title:'Créa test',kind:'video',month:'2026-10-01',file_url:'https://example.com/creative',status:'en_controle'};
  const validation={item_kind:'script',item_ref:'script-v1',decision:'valide',comment:null,created_at:'2026-10-25T07:35:33Z'};
  const avatar={name:'Avatar N1',preview_url:'https://example.com/avatar.png',chosen:false};
  for(const row of [delivery,validation,avatar]){const before=JSON.stringify(row);assert(supportedRecord(row));assert.notEqual(recordTitle(row),'Sans nom');assert.notEqual(recordStatus(row),'Statut non renseigné');assert.equal(JSON.stringify(row),before);}
  assert.equal(recordTitle(validation),'script-v1');assert.equal(recordStatus(validation),'Validé');assert.equal(recordStatusCode(validation),'valide');
  assert.equal(recordStatus(delivery),'En contrôle');assert.equal(recordLink(delivery),delivery.file_url);
  assert.equal(recordStatus(avatar),'Non sélectionné');assert.equal(recordStatus({...avatar,chosen:true}),'Sélectionné');assert.equal(recordLink(avatar),avatar.preview_url);
  assert.equal(recordStatus({status:'attente_client'}),'En attente du client');assert.equal(recordStatus({status:'attente_ibra'}),'En attente d’Ibra');
  assert.equal(recordTitle({name:null,title:'Titre présent'}),'Titre présent');
  assert(!supportedRecord({id:'unmapped'}));
});

test('client creation sends only actual columns with onboarding defaults',async()=>{
  const values=clientValues({name:'  Lashéa & Beauté  ',sector:' Beauté ',contact_email:' contact@example.test ',email:'ignored'},{create:true});
  assert.deepEqual(values,{name:'Lashéa & Beauté',slug:'lashea-beaute',sector:'Beauté',contact_email:'contact@example.test',status:'onboarding',current_step:1});
  assert.equal(clientSlug('Éclat — Paris'),'eclat-paris');assert.throws(()=>clientValues({name:'!!!'}));
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  await repo.createClient(values);assert.deepEqual(sdk.requests[0].values,values);
  const edit=clientValues({name:'Nouveau nom',sector:'Beauté',contact_email:''});
  await repo.updateClient('c',edit);assert.deepEqual(sdk.requests[1].values,{name:'Nouveau nom',slug:'nouveau-nom',sector:'Beauté',contact_email:null});
  await repo.updateClient('c',{status:'archived'});assert.deepEqual(sdk.requests[2].values,{status:'archived'});
});
test('PostgREST messages and constraint details remain exact',()=>{
  const error={code:'23505',message:'duplicate key value violates unique constraint "clients_slug_key"',details:'Key (slug)=(lashea) already exists.',hint:'Choose another slug.'};
  assert.equal(postgrestMessage(error),error.message+'\n'+error.details+'\n'+error.hint);
  assert.equal(postgrestMessage({message:"Could not find the 'email' column of 'clients' in the schema cache"}),"Could not find the 'email' column of 'clients' in the schema cache");
});

test('JSON document updates preserve structure and non-text metadata',()=>{
  const source={concept:'Concept',transcription:{hooks:['H1','H2'],corps:'Body',cta:'CTA'},acting:{plans:['Plan']},metadata:{enabled:false,count:3,extra:null}};
  const leaves=documentLeaves(source);const i=leaves.findIndex(l=>l.value==='H2');
  const changed=patchDocument(source,[[i,'Nouveau hook']]);
  assert.equal(changed.transcription.hooks[1],'Nouveau hook');assert.equal(source.transcription.hooks[1],'H2');assert.deepEqual(changed.metadata,source.metadata);assert.throws(()=>patchDocument(source,[[999,'Bad']]));
  assert.equal(recordMonth({month:'2026-10-01'}),'2026-10');assert.equal(recordMonth({created_at:'2026-10-01'}),null);
  assert.equal(briefKind({kind:'static'}),'static');assert.equal(briefKind({kind:'video'}),'video');assert.equal(briefKind({}),'unknown');
});
test('document writes are agency-only and scoped to client and row',async()=>{
  const sdk=fakeSDK(),agency=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  const row={id:'b',client_id:'client-A',content:{concept:'Old'}};
  await agency.updateDocument('briefs',row,'client-A',{concept:'New'});
  assert.deepEqual(sdk.requests[0].values,{content:{concept:'New'}});assert.deepEqual(sdk.requests[0].filters,[['client_id','client-A'],['id','b'],['content',JSON.stringify(row.content)]]);
  await agency.updateDocument('brand_dossiers',{client_id:'client-A',data:{ton:'Old'}},'client-A',{ton:'New'});
  assert.deepEqual(sdk.requests[1].values.data,{ton:'New'});assert.equal(sdk.requests[1].values.updated_by,'a');assert(Number.isFinite(Date.parse(sdk.requests[1].values.updated_at)));
  const clientRepo=new ScopedRepository(sdk,client());await assert.rejects(clientRepo.updateDocument('briefs',row,'client-A',{}));await assert.rejects(agency.updateDocument('profiles',row,'client-A',{}));await assert.rejects(agency.updateDocument('briefs',row,'client-B',{}));assert.equal(sdk.requests.length,2);
});
test('delivery gates reject client actions before Ibra and agency approval on behalf of client',async()=>{
  const sdk=fakeSDK(),agency=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a')),clientRepo=new ScopedRepository(sdk,client());
  const row={id:'d',client_id:'client-A',status:'en_controle'};
  assert(!allowedDeliveryTransition('client',row,'valide'));assert(!allowedDeliveryTransition('agency',row,'valide'));
  await assert.rejects(clientRepo.transitionDelivery(row,'client-A','valide'));assert.equal(sdk.requests.length,0);
  await agency.transitionDelivery(row,'client-A','attente_client');assert.deepEqual(sdk.requests[0].filters,[['id','d'],['client_id','client-A'],['status','en_controle']]);assert.deepEqual(sdk.requests[0].values,{status:'attente_client'});
  await clientRepo.transitionDelivery({...row,status:'attente_client'},'client-A','correction');assert.deepEqual(sdk.requests[1].values,{client_id:'client-A',item_kind:'crea',item_ref:'d',decision:'correction',decided_by:'user-A'});assert.deepEqual(sdk.requests[2].values,{status:'correction'});
  await assert.rejects(agency.transitionDelivery({...row,status:'attente_client'},'client-A','valide'));assert.equal(sdk.requests.length,3);
});
test('only the assigned client can choose avatars and the previous boolean is checked',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,client()),row={id:'av',client_id:'client-A',chosen:false};
  await repo.chooseAvatar(row,'client-A');assert.deepEqual(sdk.requests[0].values,{chosen:true});assert.deepEqual(sdk.requests[0].filters,[['id','av'],['client_id','client-A'],['chosen',false]]);
  await assert.rejects(repo.chooseAvatar({...row,client_id:'client-B'},'client-A'));
  const agency=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));await assert.rejects(agency.chooseAvatar(row,'client-A'));assert.equal(sdk.requests.length,1);
});

test('exact brief gates enforce Ibra then client for video and Ibra alone for statique',()=>{
  for(const kind of ['video','statique']){
    assert.equal(briefTransition('agency',{kind,status:'redaction'}),'attente_ibra');
    assert.equal(briefTransition('agency',{kind,status:'attente_ibra'}),kind==='video'?'attente_client':'valide');
    assert.equal(briefTransition('client',{kind,status:'attente_client'}),kind==='video'?'valide':null);
    for(const status of ['redaction','attente_ibra','valide'])assert.equal(briefTransition('client',{kind,status}),null);
    assert.equal(briefTransition('agency',{kind,status:'attente_client'}),null);
  }
  assert.equal(briefTransition('agency',{kind:'unknown',status:'redaction'}),null);
});
function decisionSDK({row,history=[],insertError=null,updateError=null,holdInsert=null}={}){
  const requests=[],records={briefs:[structuredClone(row)],validations:structuredClone(history)};
  const sdk={requests,records,updateError,from(table){const request={table,operation:'select',filters:[]};requests.push(request);const match=r=>request.filters.every(([k,v])=>r[k]===v);
    const q={select(){return q;},eq(k,v){request.filters.push([k,v]);return q;},order(){return q;},insert(values){request.operation='insert';request.values=values;return q;},update(values){request.operation='update';request.values=values;return q;},maybeSingle:async()=>({data:structuredClone(records[table].find(match)||null),error:null}),limit:async()=>({data:structuredClone(records[table].filter(match)),error:null}),single:async()=>{
      if(request.operation==='insert'){if(holdInsert)await holdInsert;if(insertError)return {data:null,error:insertError};const event={id:'event-'+records.validations.length,created_at:'2026-10-26T00:00:00Z',...request.values};records.validations.push(event);return {data:structuredClone(event),error:null};}
      if(sdk.updateError)return {data:null,error:sdk.updateError};const found=records[table].find(match);if(!found)return {data:null,error:{code:'PGRST116',message:'Cannot coerce the result to a single JSON object'}};Object.assign(found,request.values);return {data:structuredClone(found),error:null};
    }};return q;}};return sdk;
}
const decisionRow=id=>({id,client_id:'client-A',kind:'video',status:'attente_client',content:{concept:'A',transcription:{ctas:['CTA']}}});
const versionHistory=id=>[{id:'iv',client_id:'client-A',brief_id:id,item_kind:'script',item_ref:'script-v2',decision:'valide',decided_by:'agency-user',created_at:'2026-10-25T00:00:00Z'}];
test('agency approval keeps its direct history and conditional UPDATE flow',async()=>{
  const row={...decisionRow('b'),status:'attente_ibra'},sdk=decisionSDK({row,history:versionHistory('b')}),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  const result=await repo.transitionBrief(row,'client-A','attente_client','script-v2');assert.equal(result.data.status,'attente_client');
  const writes=sdk.requests.filter(r=>r.operation!=='select');assert.deepEqual(writes.map(r=>[r.table,r.operation]),[['validations','insert'],['briefs','update']]);
  assert.deepEqual(writes[0].values,{client_id:'client-A',item_kind:'script',brief_id:'b',item_ref:'script-v2',decision:'valide',decided_by:'a'});
  assert.deepEqual(writes[1].filters,[['id','b'],['client_id','client-A'],['status','attente_ibra']]);assert.equal(writes[1].values.status,'attente_client');assert.equal(writes[1].values.validated_by,'a');assert(Math.abs(Date.now()-Date.parse(writes[1].values.validated_at))<5000);
  for(const bad of [{...row,status:'attente_ibra'},{...row,kind:'unknown'},{...row,client_id:'client-B'}])await assert.rejects(repo.transitionBrief(bad,'client-A','valide'));
});
test('script version is a label from current content or the associated history, never a UUID',()=>{
  const row=decisionRow('versions');assert.equal(scriptVersion(row,versionHistory(row.id)),'script-v2');assert.equal(scriptVersion(row,[{...versionHistory(row.id)[0],item_ref:row.id}]),null);
  assert.equal(scriptVersion({...row,content:{version:'script-v3'}},versionHistory(row.id)),'script-v3');assert.equal(scriptVersion(row,[...versionHistory(row.id),{...versionHistory(row.id)[0],brief_id:'foreign',item_ref:'script-v9'}]),'script-v2');
});
test('missing or changed version sends no decision',async()=>{
  const row={...decisionRow('missing'),status:'attente_ibra'},sdk=decisionSDK({row}),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));assert.match((await repo.transitionBrief(row,'client-A','attente_client')).error.message,/version/);assert(!sdk.requests.some(r=>r.operation==='insert'));
  const known=decisionSDK({row,history:versionHistory(row.id)});assert.match((await new ScopedRepository(known,checkedProfile({id:'a',role:'agency'},'a')).transitionBrief(row,'client-A','attente_client','script-v1')).error.message,/version/);assert(!known.requests.some(r=>r.operation==='insert'));
});
test('editing an approved brief resets the approval circuit and preserves other JSON keys',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  await repo.updateDocument('briefs',{id:'b',client_id:'client-A',status:'valide',content:{concept:'Old'}},'client-A',{concept:'New'});
  assert.deepEqual(sdk.requests[0].values,{content:{concept:'New'},status:'redaction',validated_by:null,validated_at:null});assert(sdk.requests[0].filters.some(([key,value])=>key==='status'&&value==='valide'));
});

function rpcSDK({error=null,readError=null,hold=null}={}){
  const calls=[],row={...decisionRow('rpc-brief'),validated_by:null,validated_at:null};let committed=false;
  return {calls,row,async rpc(name,args){calls.push({operation:'rpc',name,args});if(hold)await hold;if(error)return {data:null,error};if(committed)return {data:null,error:{code:'P0001',message:'already_decided'}};committed=true;Object.assign(row,args.p_decision==='valide'?{status:'valide',validated_by:'user-A',validated_at:'2026-10-26T01:00:00Z'}:{status:'redaction',validated_by:null,validated_at:null});return {data:{id:'server-decision',item_ref:'script-v7',decision:args.p_decision},error:null};},from(table){const request={operation:'select',table,filters:[]};calls.push(request);const q={select(){return q;},eq(k,v){request.filters.push([k,v]);return q;},maybeSingle:async()=>({data:readError?null:structuredClone(row),error:readError})};return q;}};
}
test('client script uses only RPC and a scoped read, never direct INSERT or UPDATE',async()=>{
  const sdk=rpcSDK(),repo=new ScopedRepository(sdk,client()),row=structuredClone(sdk.row);
  const result=await repo.transitionBrief(row,'client-A','valide','obsolete-browser-version');assert.equal(result.data.status,'valide');assert.equal(result.data.validated_by,'user-A');assert.equal(result.data.validated_at,'2026-10-26T01:00:00Z');assert.equal(result.decision.item_ref,'script-v7');
  assert.deepEqual(sdk.calls,[{operation:'rpc',name:'client_decide_script',args:{p_brief_id:'rpc-brief',p_decision:'valide',p_comment:null}},{operation:'select',table:'briefs',filters:[['id','rpc-brief'],['client_id','client-A']]}]);
});
test('RPC correction is atomic and goes back to redaction',async()=>{
  const sdk=rpcSDK(),repo=new ScopedRepository(sdk,client());const result=await repo.transitionBrief(structuredClone(sdk.row),'client-A','redaction');assert.equal(result.data.status,'redaction');assert.equal(sdk.calls[0].args.p_decision,'correction');assert.equal(result.decision.decision,'correction');assert(sdk.calls.every(c=>c.operation==='rpc'||c.operation==='select'));
});
test('all documented RPC errors have honest French messages and no direct write fallback',async()=>{
  const cases={not_authenticated:'connecté',not_a_client:'compte client',brief_not_found:'accessible',wrong_client:'espace client',static_brief_ibra_only:'validés par Ibra','wrong_state: redaction':'pas en attente',bad_decision:'correction',already_decided:'déjà enregistré'};
  for(const [message,fragment] of Object.entries(cases)){
    const sdk=rpcSDK({error:{code:'P0001',message}}),result=await new ScopedRepository(sdk,client()).transitionBrief(structuredClone(sdk.row),'client-A','valide');assert.equal(result.error.message,message);assert(result.userMessage.includes(fragment));assert.equal(result.partial,undefined);assert(!sdk.calls.some(c=>c.operation==='insert'||c.operation==='update'));assert(clientScriptError(result.error).includes(fragment));
  }
});
test('concurrent client clicks make a single RPC; repeat decisions remain server-controlled',async()=>{
  let release;const hold=new Promise(resolve=>release=resolve),sdk=rpcSDK({hold}),repo=new ScopedRepository(sdk,client()),row=structuredClone(sdk.row);
  const first=repo.transitionBrief(row,'client-A','valide'),second=repo.transitionBrief(row,'client-A','valide');release();await Promise.all([first,second]);assert.equal(sdk.calls.filter(c=>c.operation==='rpc').length,1);
  const repeat=await repo.transitionBrief(row,'client-A','valide');assert.equal(repeat.error.message,'already_decided');assert.equal(repeat.terminal,true);assert.equal(repeat.currentRow.status,'valide');
});
test('RPC success remains success if the brief reload fails; no invented timestamp or retry UPDATE',async()=>{
  const sdk=rpcSDK({readError:{message:'Read temporarily unavailable'}}),repo=new ScopedRepository(sdk,client()),result=await repo.transitionBrief(structuredClone(sdk.row),'client-A','valide');assert.equal(result.rpcSuccess,true);assert.equal(result.error,null);assert.equal(result.data.id,'rpc-brief');assert.equal(result.data.status,'valide');assert.equal(result.data.validated_at,undefined);assert(result.refreshError);assert.equal(result.partial,undefined);
});
test('foreign clients are refused before RPC and client cannot use the legacy agency method',async()=>{
  const sdk=rpcSDK(),repo=new ScopedRepository(sdk,client());await assert.rejects(repo.transitionBrief({...sdk.row,client_id:'client-B'},'client-A','valide'));await assert.rejects(repo.performAgencyBriefTransition(sdk.row,'client-A','valide'));assert.equal(sdk.calls.length,0);
});

test('new agency brief uses the real schema, empty editable content, client and displayed month',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  await repo.createBrief('client-A',{title:' Nouveau concept ',month:'2026-11',kind:'video'});
  assert.deepEqual(sdk.requests[0].values,{client_id:'client-A',month:'2026-11-01',kind:'video',title:'Nouveau concept',status:'redaction',source:'agence',content:{concept:'',transcription:{hooks:[''],corps:'',ctas:['']},acting:''}});
  await repo.createBrief('client-A',{title:'Statique',month:'2026-12',kind:'static'});assert.equal(sdk.requests[1].values.kind,'statique');assert.deepEqual(sdk.requests[1].values.content,{reference:'',angle:'',overlay:''});
  for(const input of [{title:'',month:'2026-10',kind:'video'},{title:'A',month:'2026-13',kind:'video'},{title:'A',month:'2026-10',kind:'unknown'}])assert.throws(()=>newBriefValues('client-A',input));
});
test('brief trash persists archived status and restoration starts a new approval circuit',async()=>{
  const row={id:'trash',client_id:'client-A',status:'attente_ibra',content:{concept:'Preserved'}},sdk=decisionSDK({row}),repo=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));
  const archived=await repo.archiveBrief(row,'client-A');assert.equal(archived.data.status,'archived');assert.deepEqual(sdk.requests[0].values,{status:'archived'});assert.deepEqual(sdk.requests[0].filters,[['id','trash'],['client_id','client-A'],['status','attente_ibra']]);
  const reloaded=await sdk.from('briefs').select('*').eq('id','trash').eq('client_id','client-A').maybeSingle();assert.equal(reloaded.data.status,'archived');assert.deepEqual(reloaded.data.content,row.content);
  const restored=await repo.restoreBrief(reloaded.data,'client-A');assert.equal(restored.data.status,'redaction');assert.equal(restored.data.validated_by,null);assert.equal(restored.data.validated_at,null);assert.deepEqual(restored.data.content,row.content);
});
test('brief create and trash respect roles/scopes and propagate RLS errors without success',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,client()),row={id:'b',client_id:'client-A',status:'redaction'};
  await assert.rejects(repo.createBrief('client-A',{title:'Forbidden',month:'2026-10',kind:'video'}));await assert.rejects(repo.archiveBrief(row,'client-A'));await assert.rejects(repo.restoreBrief({...row,status:'archived'},'client-A'));assert.equal(sdk.requests.length,0);
  const agency=new ScopedRepository(sdk,checkedProfile({id:'a',role:'agency'},'a'));await assert.rejects(agency.archiveBrief({...row,client_id:'client-B'},'client-A'));assert.equal(sdk.requests.length,0);
  const error={code:'42501',message:'new row violates row-level security policy for table "briefs"'},denied={from(){const q={insert(){return q;},select(){return q;},single:async()=>({data:null,error})};return q;}};
  const result=await new ScopedRepository(denied,checkedProfile({id:'a',role:'agency'},'a')).createBrief('client-A',{title:'Denied',month:'2026-10',kind:'video'});assert.equal(result.data,null);assert.equal(result.error,error);
});
test('decision author roles come only from accessible profiles for scoped history',async()=>{
  let requested;
  const sdk={from(table){assert.equal(table,'profiles');return {select(cols){assert.equal(cols,'id, role');return {in(key,ids){requested=ids;assert.equal(key,'id');return Promise.resolve({data:[{id:'agency-1',role:'agency'},{id:'unknown',role:'agency'}],error:null});}};}};}};
  const repo=new ScopedRepository(sdk,client());
  const decisions=[{client_id:'client-A',decided_by:'agency-1'},{client_id:'client-A',decided_by:'user-A'},{client_id:'client-B',decided_by:'foreign'}];
  const result=await repo.decisionAuthors('client-A',decisions);
  assert.deepEqual(requested,['agency-1','user-A']);assert.deepEqual(result.rows,[{id:'user-A',role:'client'},{id:'agency-1',role:'agency'}]);
  await assert.rejects(repo.decisionAuthors('client-B',decisions));
});
test('unreadable author profiles never produce an invented agency role',async()=>{
  const repo=new ScopedRepository({from(){return {select(){return {in(){return Promise.resolve({data:null,error:{code:'42501'}});}};}};}},client());
  const result=await repo.decisionAuthors('client-A',[{client_id:'client-A',decided_by:'agency-1'}]);assert.deepEqual(result.rows,[]);assert.equal(result.error.code,'42501');
});

test('delivery creation requires agency, binds client and starts at internal review',async()=>{
  const sdk=fakeSDK(),repo=new ScopedRepository(sdk,checkedProfile({id:'agency',role:'agency'},'agency'));
  const input={title:'Création réelle',month:'2026-10',kind:'video',file_url:'https://example.com/video'};
  const result=await repo.createDelivery('client-A',input);
  assert.equal(result.data.client_id,'client-A');assert.equal(result.data.status,'en_controle');assert.equal(result.data.month,'2026-10-01');
  const forbidden=new ScopedRepository(fakeSDK(),client());await assert.rejects(forbidden.createDelivery('client-A',input));
  for(const file_url of ['javascript:alert(1)','http://example.com','https://user:pass@example.com'])await assert.rejects(repo.createDelivery('client-A',{...input,file_url}));
  await assert.rejects(repo.createDelivery('client-A',{...input,month:'2026-13'}));
});
