/* Manual integration harness, NOT executed by the agent. Only existing .test/.invalid fixtures. */
import {createClient} from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';
import {ScopedRepository,checkedProfile} from '../../dist/supabase-store.js';
const URL='https://xqacgjtlktzrmfcolbst.supabase.co';
const KEY='sb_publishable_WMR8B31BdcISZgTif42jBg_si336W0Z';
const $=selector=>document.querySelector(selector);
const stable=value=>JSON.stringify(value,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const equal=(a,b)=>stable(a)===stable(b);
const clone=value=>JSON.parse(JSON.stringify(value));
const check=(ok,label)=>{if(!ok)throw new Error(label);};
const issue=error=>String(error?.code||'network_or_unconfirmed');
const lines=[];let agency,client,target,initial,originalClient,originalProfiles,owned=[],writeAttempted=false,running=false,needsRestore=false;
const emit=(state,label)=>{lines.push({state,label,at:new Date().toISOString()});$('#results').textContent=lines.map(x=>x.state+' — '+x.label).join('\n');};
function fixtureEmail(email,local){return typeof email==='string'&&email.split('@')[0]===local&&/\.(test|invalid)$/i.test(email);}
function sdk(){return createClient(URL,KEY,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false,storageKey:'brain-review-'+crypto.getRandomValues(new Uint32Array(2)).join('-')},global:{headers:{'Cache-Control':'no-store'}}});}
async function signIn(email,password,local,role){check(fixtureEmail(email,local),'Utilise uniquement le compte fictif '+local+' sur un domaine .test/.invalid.');const api=sdk();try{const signed=await api.auth.signInWithPassword({email,password});check(!signed.error,'Connexion fixture refusée : '+issue(signed.error));const own=await api.auth.getUser();check(!own.error&&own.data.user,'Session non vérifiée.');check(fixtureEmail(own.data.user.email,local),'Identité Auth inattendue.');const p=await api.from('profiles').select('id, role, client_id').eq('id',own.data.user.id).maybeSingle();check(!p.error,'Profil inaccessible.');const profile=checkedProfile(p.data,own.data.user.id);check(profile.role===role,'Rôle fixture inattendu.');return {sdk:api,user:own.data.user,profile,repo:new ScopedRepository(api,profile)};}catch(error){try{await api.auth.signOut({scope:'local'});}catch{}throw error;}}
async function dossier(account,id){const result=await account.sdk.from('brand_dossiers').select('*').eq('client_id',id).limit(2);check(!result.error,'Lecture dossier refusée : '+issue(result.error));check(result.data?.length===1,'Il faut exactement un dossier existant pour cette fixture. Aucun INSERT ne sera tenté.');return result.data[0];}
async function ownProfile(account){const result=await account.sdk.from('profiles').select('id, role, client_id').eq('id',account.user.id).maybeSingle();check(!result.error,'Relecture profil impossible.');return result.data;}
async function clientRow(){const result=await agency.sdk.from('clients').select('*').eq('id',target).maybeSingle();check(!result.error&&result.data,'Fiche client inaccessible.');return result.data;}
async function cleanup(){
 if(!writeAttempted)return true;
 const latest=await dossier(agency,target);
 if(equal(latest,initial)){emit('PASS','État initial déjà intact.');needsRestore=false;return true;}
 // Never erase another writer's unknown keys or metadata. Only restore our exact known payload.
 const belongs=owned.some(data=>equal(data,latest.data))&&latest.updated_by===agency.user.id;
 check(belongs,'NETTOYAGE BLOQUÉ : le dossier a changé hors de cette recette. Aucune restauration forcée.');
 let query=agency.sdk.from('brand_dossiers').update({data:clone(initial.data),updated_at:initial.updated_at,updated_by:initial.updated_by}).eq('client_id',target).eq('data',JSON.stringify(latest.data));
 if(initial.id!==undefined)query=query.eq('id',initial.id);
 query=latest.updated_at==null?query.is('updated_at',null):query.eq('updated_at',latest.updated_at);
 const restored=await query.select('*').single();check(!restored.error&&restored.data,'NETTOYAGE NON CONFIRMÉ : conflit/RLS/réseau. '+issue(restored.error));
 const final=await dossier(agency,target);check(equal(final,initial),'NETTOYAGE INCOMPLET : la ligne entière diffère de son état initial.');needsRestore=false;emit('PASS','Restauration et relecture : ligne entière identique (data et métadonnées).');return true;
}
async function logout(){for(const account of [client,agency])if(account)try{const r=await account.sdk.auth.signOut({scope:'local'});emit(r.error?'WARN':'PASS',r.error?'Déconnexion fixture non confirmée.':'Session de recette fermée localement.');}catch{emit('WARN','Déconnexion fixture non confirmée.');}}
$('#login-form').addEventListener('submit',async event=>{
 event.preventDefault();if(running)return;running=true;$('#login-submit').disabled=true;const form=event.target,fields=new FormData(form);
 try{agency=await signIn(String(fields.get('agencyEmail')||'').trim(),String(fields.get('agencyPassword')||''),'agency.demo','agency');client=await signIn(String(fields.get('clientEmail')||'').trim(),String(fields.get('clientPassword')||''),'cliente.demo','client');target=client.profile.client_id;originalClient=await clientRow();check(originalClient.status!=='archived','Fixture archivée : recette refusée.');initial=clone(await dossier(agency,target));check(initial.data&&typeof initial.data==='object'&&!Array.isArray(initial.data),'Dossier incompatible : aucune écriture autorisée.');check(Object.hasOwn(initial,'updated_at')&&Object.hasOwn(initial,'updated_by'),'Métadonnées manquantes : restauration exacte non garantie.');window.IconFlowBrainIntake.readBrain(initial.data);originalProfiles=[await ownProfile(agency),await ownProfile(client)];emit('PASS','Sessions, rôles, fiche et dossier existant vérifiés (lecture uniquement).');$('#target').textContent=(originalClient.name||'Fixture')+' · '+target;$('#run-section').hidden=false;$('#login-form').hidden=true;
 }catch(error){emit('BLOCKED',error.message);await logout();agency=client=null;}finally{form.querySelectorAll('input[type=password]').forEach(el=>el.value='');running=false;$('#login-submit').disabled=false;}
});
$('#run').addEventListener('click',async()=>{
 if(running||!agency||!client)return;if(!$('#fixture-consent').checked){emit('BLOCKED','Confirme que cette fiche est fictive et autorisée.');return;}running=true;$('#run').disabled=true;let success=false;
 try{
  // Refresh the baseline immediately before the first write; no durable snapshot is stored.
  initial=clone(await dossier(agency,target));originalClient=await clientRow();originalProfiles=[await ownProfile(agency),await ownProfile(client)];
  const id='fixture-brain-'+crypto.getRandomValues(new Uint32Array(4)).join('-');
  const answers=window.IconFlowBrainIntake.classify({promise:'RÉPONSE FICTIVE DE RECETTE — à retirer automatiquement après vérification.'});
  const next=window.IconFlowBrainIntake.mergeReview(initial.data,answers,{id,actor:agency.user.id,at:new Date().toISOString()});
  owned.push(clone(next));writeAttempted=true;needsRestore=true;
  const saved=await agency.repo.updateDocument('brand_dossiers',initial,target,next);check(!saved.error&&saved.data,'Sauvegarde agence refusée/non confirmée : '+issue(saved.error));check(equal(saved.data.data,next),'Le contenu confirmé diffère du contenu envoyé.');emit('PASS','Sauvegarde agence réelle par ScopedRepository.updateDocument.');
  const reread=await dossier(agency,target);check(equal(reread.data,next),'La relecture ne retrouve pas exactement le contenu enregistré.');emit('PASS','Nouvelle requête de lecture serveur : réponse fictive et toutes les clés conservées.');
  // A competing payload based on the OLD full JSON must modify zero rows.
  const stale=window.IconFlowBrainIntake.mergeReview(initial.data,answers,{id:id+'-stale',actor:agency.user.id,at:new Date().toISOString()});owned.push(clone(stale));
  const conflict=await agency.repo.updateDocument('brand_dossiers',initial,target,stale);check(conflict.error?.code==='PGRST116'&&!conflict.data,'ÉCHEC CAS : attendu zéro ligne/PGRST116, reçu '+issue(conflict.error));check(equal((await dossier(agency,target)).data,next),'Le conflit CAS a modifié le contenu.');emit('PASS','CAS périmé refusé : zéro ligne et contenu courant intact.');
  const own=await client.repo.table('brand_dossiers',target);check(!own.error&&own.rows.length===1&&equal(own.rows[0].data,next),'Lecture client de son dossier non confirmée.');emit('PASS','Client : lecture du seul dossier assigné, aucune note agence chargée.');
  // Intentional RLS negative test. It does NOT send a different data payload.
  const denied=await client.sdk.from('brand_dossiers').update({data:clone(next)}).eq('client_id',target).eq('data',JSON.stringify(next)).select('client_id');
  check(denied.error?.code==='42501'||!denied.error&&Array.isArray(denied.data)&&denied.data.length===0,'ÉCHEC RLS : le client peut écrire son dossier (mise à jour témoin identique).');check(equal((await dossier(agency,target)).data,next),'Le contrôle client a modifié le contenu.');emit('PASS','Client : UPDATE direct du dossier refusé (pas seulement un bouton masqué).');
  const foreign=await agency.sdk.from('brand_dossiers').select('client_id').neq('client_id',target).limit(1);check(!foreign.error,'Recherche du témoin inter-client impossible.');
  if(foreign.data?.length){const foreignId=String(foreign.data[0].client_id);let refused=false;try{await client.repo.table('brand_dossiers',foreignId);}catch{refused=true;}check(refused,'Le repository client accepte un autre client.');
   // Deliberate negative test outside the product repository, only client_id is selected.
   const isolated=await client.sdk.from('brand_dossiers').select('client_id').eq('client_id',foreignId).limit(1);check(!isolated.error&&Array.isArray(isolated.data)&&isolated.data.length===0||isolated.error?.code==='42501','ÉCHEC RLS : dossier étranger lisible.');emit('PASS','Autre dossier existant : repository refuse avant requête et RLS refuse la lecture directe.');
  }else emit('SKIP','Aucun autre dossier témoin existant : isolation inter-client NON PROUVÉE. Aucun dossier créé.');
  success=true;
 }catch(error){emit('FAIL',error.message);}finally{
  try{await cleanup();const afterClient=await clientRow();check(equal(afterClient,originalClient),'La fiche client entière diffère de son état initial.');check(equal(await ownProfile(agency),originalProfiles[0])&&equal(await ownProfile(client),originalProfiles[1]),'Les profils diffèrent de leur état initial.');emit('PASS','Fiche client, status/current_step et profils inchangés.');}catch(error){needsRestore=true;emit('CLEANUP_REQUIRED',error.message);$('#backup-section').hidden=false;}
  if(!needsRestore)await logout();running=false;emit(success&&!needsRestore?'DONE':'NOT_PASSED',success&&!needsRestore?'Recette exécutée et restaurée ; vérifier les éventuels SKIP.':'Ne pas déclarer la recette réussie. Voir FAIL/CLEANUP_REQUIRED/SKIP.');
 }
});
$('#retry-cleanup').addEventListener('click',async()=>{if(running||!needsRestore)return;running=true;try{await cleanup();emit('PASS','Nettoyage confirmé après nouvelle tentative.');await logout();$('#backup-section').hidden=true;}catch(error){emit('CLEANUP_REQUIRED',error.message);}finally{running=false;}});
$('#download-backup').addEventListener('click',()=>{if(!initial)return;const blob=new Blob([JSON.stringify({project:URL,client_id:target,initial_row:initial,report:lines},null,2)],{type:'application/json'});const link=document.createElement('a');link.href=URLGlobal.createObjectURL(blob);link.download='brain-fixture-initial-and-report.json';link.click();setTimeout(()=>URLGlobal.revokeObjectURL(link.href),1000);});
const URLGlobal=window.URL;
window.addEventListener('beforeunload',event=>{if(running||needsRestore){event.preventDefault();event.returnValue='';}});
