import test from 'node:test';
import assert from 'node:assert/strict';
import {visualWatchdog} from '../src/brain-visual-state.js';
import {readWithTimeout} from '../dist/supabase-store.js';
function fixture(){
 const scheduled=new Map();let next=0,stops=0;
 const timers={setTimeout(fn,ms){const id=++next;scheduled.set(id,{fn,ms});return id;},clearTimeout(id){scheduled.delete(id);}};
 const el=()=>({dataset:{},children:[],hidden:false,append(...children){this.children.push(...children);},replaceChildren(...children){this.children=children;},setAttribute(k,v){this[k]=v;},remove(){this.removed=true;}});
 const stage=el(),host=el(),status=el(),hint=el(),document={createElement:el};
 const watch=visualWatchdog({stage,host,status,hint,document,timers,onFallback(){stops++;}});
 return {watch,stage,host,status,hint,timers,scheduled,stops:()=>stops};
}
test('stalled visual reaches static fallback after 8000ms and late readiness cannot revive it',()=>{
 const f=fixture();f.watch.start();const job=[...f.scheduled.values()][0];assert.equal(job.ms,8000);job.fn();
 assert.equal(f.stage.dataset.renderState,'fallback');assert(f.status.hidden);assert(f.host.hidden);assert(f.hint.hidden);assert.equal(f.stops(),1);
 const figure=f.stage.children[0];assert.equal(figure.children[0].src,'assets/brain-visual.svg');assert.equal(figure.children[1].children[0].textContent,'Visuel 3D indisponible sur cet appareil');
 assert.equal(f.watch.ready(),false);f.watch.fail('late-error');assert.equal(f.stops(),1);assert.equal(f.stage.children.length,1);
});
test('first rendered frame cancels deadline; dispose clears timer and suppresses late callbacks',()=>{
 const f=fixture();f.watch.start();assert(f.watch.ready());assert.equal(f.scheduled.size,0);assert(f.status.hidden);assert.equal(f.stage.dataset.renderState,'ready');
 f.watch.start();const old=[...f.scheduled.values()][0];f.watch.dispose();assert.equal(f.scheduled.size,0);old.fn();assert.equal(f.stops(),0);assert.equal(f.stage.children.length,0);
});
test('explicit renderer/model failure uses same honest static fallback without a spinner',()=>{
 const f=fixture();f.watch.start();f.watch.fail('model-load');assert.equal(f.stage.dataset.renderState,'fallback');assert(f.status.hidden);assert.equal(f.scheduled.size,0);
});
test('read deadline reports timeout instead of inventing data; late read cannot replace timeout',async()=>{
 const f=fixture();let complete;const read=readWithTimeout(()=>new Promise(resolve=>{complete=resolve;}),12000,f.timers);
 await Promise.resolve();const job=[...f.scheduled.values()][0];assert.equal(job.ms,12000);job.fn();await assert.rejects(read,{code:'READ_TIMEOUT'});complete({rows:[{data:'late'}]});assert.equal(f.scheduled.size,0);
});
test('successful reads preserve real data and clear their deadline; original failures survive',async()=>{
 const f=fixture(),data={rows:[{client_id:'real-client',data:{promesse:'Existing data'}}],error:null};
 assert.equal(await readWithTimeout(()=>data,12000,f.timers),data);assert.equal(f.scheduled.size,0);
 const error=new Error('network');await assert.rejects(readWithTimeout(()=>Promise.reject(error),12000,f.timers),error);assert.equal(f.scheduled.size,0);
});
