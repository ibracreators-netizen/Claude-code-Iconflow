// This watchdog owns only the decorative visual, never the client's Brain data.
export function visualWatchdog({stage,host,status,hint,onFallback,timeoutMs=8000,timers=globalThis,document:doc=stage.ownerDocument}) {
  let timer=null,disposed=false,terminal=false,fallback=null;
  const clear=()=>{if(timer!==null)timers.clearTimeout(timer);timer=null;};
  function fail(reason='timeout'){
    if(disposed||terminal)return;
    terminal=true;clear();stage.dataset.renderState='fallback';
    if(status){status.hidden=true;status.replaceChildren();}
    if(hint)hint.hidden=true;
    host.hidden=true;
    fallback=doc.createElement('figure');fallback.className='brain-static-fallback';
    const image=doc.createElement('img');image.src='assets/brain-visual.svg';image.alt='';image.width=420;image.height=280;
    const caption=doc.createElement('figcaption');caption.setAttribute('role','status');
    const title=doc.createElement('strong');title.textContent='Visuel 3D indisponible sur cet appareil';
    const detail=doc.createElement('span');detail.textContent='Aperçu statique. Les informations de ta marque restent accessibles ci-dessous.';
    caption.append(title,detail);fallback.append(image,caption);stage.append(fallback);
    onFallback?.(reason);
  }
  return {
    start(){if(disposed||terminal)return;clear();stage.dataset.renderState='loading';if(status)status.hidden=false;timer=timers.setTimeout(()=>fail('timeout'),timeoutMs);},
    ready(){if(disposed||terminal)return false;clear();stage.dataset.renderState='ready';if(status)status.hidden=true;return true;},
    fail,
    dispose(){disposed=true;clear();fallback?.remove();fallback=null;},
  };
}
