import { Editor, Node } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { TextSelection } from '@tiptap/pm/state';
import { closeHistory } from '@tiptap/pm/history';

const MAX_FILE_SIZE = 100 * 1024 * 1024;
const DB_NAME = 'iconflow-document-assets';
const STORE_NAME = 'assets';
const mounted = new WeakMap();
let databasePromise;

function element(tag, className = '', text = '') {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function safeLink(value) {
  const text = String(value || '').trim();
  if (!text || /[\u0000-\u0020\u007f]/.test(text)) return '';
  try {
    const url = new URL(text);
    if (url.username || url.password) return '';
    if ((url.protocol === 'https:' || url.protocol === 'http:') && url.hostname) return url.href;
    if (url.protocol === 'mailto:' && url.pathname && !/%0[ad]/i.test(text)) return url.href;
  } catch {}
  return '';
}

export function plainTextDoc(value = '') {
  return { type: 'doc', content: String(value ?? '').replace(/\r\n?/g, '\n').split('\n').map(line => (
    line ? { type: 'paragraph', content: [{ type: 'text', text: line }] } : { type: 'paragraph' }
  )) };
}

// Persisted JSON and pasted HTML never become an arbitrary HTML surface.
function cleanDocument(input) {
  if (!input || typeof input === 'string') return plainTextDoc(input || '');
  const allowedNodes = new Set(['doc', 'paragraph', 'heading', 'blockquote', 'bulletList', 'orderedList', 'listItem', 'codeBlock', 'horizontalRule', 'hardBreak', 'text', 'mediaAsset']);
  const marks = new Set(['bold', 'italic', 'underline', 'strike', 'code']);
  function clean(node, depth = 0) {
    if (!node || typeof node !== 'object' || depth > 60 || !allowedNodes.has(node.type)) return null;
    const result = { type: node.type };
    if (node.type === 'text') {
      if (typeof node.text !== 'string' || !node.text) return null;
      result.text = node.text;
      const safeMarks = (Array.isArray(node.marks) ? node.marks : []).flatMap(mark => {
        if (marks.has(mark?.type)) return [{ type: mark.type }];
        const href = mark?.type === 'link' && safeLink(mark.attrs?.href);
        return href ? [{ type: 'link', attrs: { href, target: '_blank', rel: 'noopener noreferrer' } }] : [];
      });
      if (safeMarks.length) result.marks = safeMarks;
    } else if (node.type === 'mediaAsset') {
      const attrs = node.attrs || {};
      result.attrs = {
        assetId: /^[a-zA-Z0-9_-]{8,160}$/.test(String(attrs.assetId || '')) ? String(attrs.assetId) : '',
        kind: ['image', 'video'].includes(attrs.kind) ? attrs.kind : 'file',
        name: String(attrs.name || 'Fichier joint').slice(0, 500),
        mime: String(attrs.mime || '').slice(0, 120),
        size: Math.max(0, Number(attrs.size) || 0),
      };
    } else {
      if (node.type === 'heading') result.attrs = { level: [1, 2, 3].includes(Number(node.attrs?.level)) ? Number(node.attrs.level) : 2 };
      if (node.type === 'orderedList') result.attrs = { start: Math.max(1, Math.min(100000, Number(node.attrs?.start) || 1)) };
      if (Array.isArray(node.content)) result.content = node.content.map(child => clean(child, depth + 1)).filter(Boolean);
    }
    return result;
  }
  const doc = clean(input);
  return doc?.type === 'doc' && doc.content?.length ? doc : plainTextDoc('');
}

function database() {
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) { reject(new Error('Stockage local indisponible.')); return; }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
    request.onerror = () => reject(request.error || new Error('Stockage local indisponible.'));
    request.onblocked = () => reject(new Error('Ferme les autres onglets IconFlow puis réessaie.'));
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => { db.close(); databasePromise = undefined; };
      resolve(db);
    };
  }).catch(error => { databasePromise = undefined; throw error; });
  return databasePromise;
}

async function storeAsset(file) {
  const db = await database();
  const id = `asset-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`}`;
  const record = { id, blob: file, name: file.name || 'Fichier joint', mime: file.type || '', size: file.size, createdAt: Date.now() };
  await new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    transaction.objectStore(STORE_NAME).put(record);
    // A successful request alone is insufficient: quota failures may abort the commit.
    transaction.oncomplete = resolve;
    transaction.onabort = () => reject(transaction.error || new Error('Le fichier n’a pas pu être conservé.'));
    transaction.onerror = () => {};
  });
  return record;
}

async function readAsset(id) {
  const db = await database();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function mediaKind(mime) {
  if (/^image\/(png|jpeg|webp|gif|avif|bmp)$/i.test(mime)) return 'image';
  if (/^video\//i.test(mime)) return 'video';
  return 'file';
}

function fileSize(bytes) {
  return bytes >= 1024 * 1024 ? `${(bytes / (1024 * 1024)).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} Mo` : `${Math.max(1, Math.round(bytes / 1024))} Ko`;
}

const MediaAsset = Node.create({
  name: 'mediaAsset',
  group: 'block',
  atom: true,
  draggable: true,
  selectable: true,
  addAttributes() {
    return {
      assetId: { default: '', parseHTML: el => el.getAttribute('data-asset-id') || '' },
      kind: { default: 'file', parseHTML: el => el.getAttribute('data-kind') || 'file' },
      name: { default: 'Fichier joint', parseHTML: el => el.getAttribute('data-name') || 'Fichier joint' },
      mime: { default: '', parseHTML: el => el.getAttribute('data-mime') || '' },
      size: { default: 0, parseHTML: el => Number(el.getAttribute('data-size')) || 0 },
    };
  },
  parseHTML() { return [{ tag: 'div[data-iconflow-asset][data-asset-id]' }]; },
  renderHTML({ node }) {
    return ['div', { 'data-iconflow-asset': '', 'data-asset-id': node.attrs.assetId, 'data-kind': node.attrs.kind, 'data-name': node.attrs.name, 'data-mime': node.attrs.mime, 'data-size': node.attrs.size }, node.attrs.name];
  },
  addNodeView() {
    return ({ node, editor, getPos }) => {
      let disposed = false, objectURL = '';
      const dom = element('figure', 'if-rich-asset');
      dom.contentEditable = 'false';
      dom.dataset.kind = node.attrs.kind;
      const preview = element('div', 'if-rich-asset-preview');
      const waiting = element('p', 'if-rich-asset-message', 'Chargement du fichier…');
      preview.append(waiting);
      const caption = element('figcaption', 'if-rich-asset-caption');
      const info = element('div', 'if-rich-asset-info');
      info.append(element('strong', '', node.attrs.name), element('span', '', fileSize(node.attrs.size)));
      const actions = element('div', 'if-rich-asset-actions');
      const download = element('a', '', 'Télécharger');
      download.hidden = true;
      const remove = element('button', '', 'Retirer');
      remove.type = 'button';
      remove.setAttribute('aria-label', `Retirer ${node.attrs.name} du document`);
      remove.addEventListener('click', event => {
        event.preventDefault();
        const pos = getPos();
        if (typeof pos === 'number' && !editor.isDestroyed) editor.chain().focus().command(({ tr }) => {
          closeHistory(tr);
          return true;
        }).deleteRange({ from: pos, to: pos + node.nodeSize }).run();
      });
      actions.append(download, remove);
      caption.append(info, actions);
      dom.append(preview, caption);
      readAsset(node.attrs.assetId).then(record => {
        if (disposed) return;
        if (!record?.blob) throw new Error('Fichier absent');
        objectURL = URL.createObjectURL(record.blob);
        const kind = mediaKind(record.mime || record.blob.type || '');
        dom.dataset.kind = kind;
        download.href = objectURL;
        download.download = String(record.name || node.attrs.name).replace(/[\u0000-\u001f\u007f]/g, '');
        download.hidden = false;
        preview.replaceChildren();
        if (kind === 'image' || kind === 'video') {
          const media = element(kind === 'image' ? 'img' : 'video');
          if (kind === 'image') { media.alt = record.name || node.attrs.name; media.loading = 'lazy'; }
          else { media.controls = true; media.preload = 'metadata'; media.playsInline = true; }
          media.src = objectURL;
          media.addEventListener('error', () => {
            if (disposed) return;
            preview.replaceChildren(element('p', 'if-rich-asset-message', 'Aperçu indisponible pour ce format. Le fichier reste téléchargeable.'));
          }, { once: true });
          preview.append(media);
        } else {
          preview.append(element('span', 'if-rich-file-icon', '↧'), element('span', 'if-rich-file-label', 'Pièce jointe'));
        }
      }).catch(() => {
        if (!disposed) preview.replaceChildren(element('p', 'if-rich-asset-message is-error', 'Fichier indisponible dans ce navigateur. Réimporte-le depuis ton appareil.'));
      });
      return {
        dom,
        stopEvent: event => Boolean(event.target.closest?.('button, a, video')),
        ignoreMutation: () => true,
        destroy() {
          disposed = true;
          const video = preview.querySelector('video');
          if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
          if (objectURL) { URL.revokeObjectURL(objectURL); objectURL = ''; }
        },
      };
    };
  },
});

const icons = {
  bold: '<path d="M6 4h7a4 4 0 0 1 0 8H6zM6 12h8a4 4 0 0 1 0 8H6z"/>',
  italic: '<path d="M10 4h9M5 20h9M15 4 9 20"/>',
  underline: '<path d="M6 3v8a6 6 0 0 0 12 0V3M4 21h16"/>',
  bullet: '<path d="M9 6h12M9 12h12M9 18h12"/><circle cx="3" cy="6" r=".7"/><circle cx="3" cy="12" r=".7"/><circle cx="3" cy="18" r=".7"/>',
  number: '<path d="M10 6h11M10 12h11M10 18h11M3 3h1v5M2 8h4M2 13c0-3 4-3 4 0 0 2-4 2-4 5h4"/>',
  quote: '<path d="M5 6h5v7H4v-2c0-4 1-5 3-6M15 6h5v7h-6v-2c0-4 1-5 3-6"/>',
  divider: '<path d="M3 12h18"/>',
  link: '<path d="m10 13 4-4M8 16l-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0M13 7l2-2a4 4 0 1 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(1 0) scale(.92)"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1"/><path d="m3 17 5-5 4 4 4-6 5 7"/>',
  video: '<rect x="2" y="5" width="14" height="14" rx="2"/><path d="m16 10 6-4v12l-6-4"/>',
  file: '<path d="m8 13 7-7a3 3 0 0 1 4 4l-9 9a5 5 0 0 1-7-7l9-9M7 16l9-9"/>',
  undo: '<path d="M3 10h11a6 6 0 0 1 0 12M3 10l5-5M3 10l5 5" transform="translate(0 -2)"/>',
  redo: '<path d="M21 10H10a6 6 0 0 0 0 12M21 10l-5-5M21 10l-5 5" transform="translate(0 -2)"/>',
};

export function mount({ element: host, doc, onChange = () => {}, onStatus = () => {} }) {
  if (!host?.append) throw new TypeError('Un élément hôte est nécessaire pour le document.');
  mounted.get(host)?.destroy();
  host.replaceChildren();
  host.classList.add('if-rich-editor');
  let editor, destroyed = false, linkBookmark = null, pickerBookmark = null;
  let importQueue = Promise.resolve();
  let lastJSON = cleanDocument(doc);
  const bookmarks = new Set();
  const toolbar = element('div', 'if-rich-toolbar');
  toolbar.setAttribute('role', 'toolbar');
  toolbar.setAttribute('aria-label', 'Mise en forme du document');
  const blockSelect = element('select', 'if-rich-block-select');
  blockSelect.setAttribute('aria-label', 'Style du paragraphe');
  [['paragraph', 'Texte'], ['h1', 'Titre 1'], ['h2', 'Titre 2'], ['h3', 'Titre 3']].forEach(([value, text]) => {
    const option = element('option', '', text); option.value = value; blockSelect.append(option);
  });
  toolbar.append(blockSelect);
  const buttons = {};
  function tool(id, title, action, text = '') {
    const button = element('button', 'if-rich-tool');
    button.type = 'button'; button.title = title; button.setAttribute('aria-label', title);
    button.dataset.richAction = id;
    // The only HTML generated here is this fixed, internal icon set.
    button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[id]}</svg>`;
    if (text) button.append(element('span', '', text));
    button.addEventListener('mousedown', event => event.preventDefault());
    button.addEventListener('click', () => { if (!destroyed) action(); });
    buttons[id] = button;
    toolbar.append(button);
    return button;
  }
  function divider() { const d = element('span', 'if-rich-toolbar-divider'); d.setAttribute('aria-hidden', 'true'); toolbar.append(d); }
  tool('bold', 'Gras · ⌘/Ctrl B', () => editor.chain().focus().toggleBold().run());
  tool('italic', 'Italique · ⌘/Ctrl I', () => editor.chain().focus().toggleItalic().run());
  tool('underline', 'Souligner · ⌘/Ctrl U', () => editor.chain().focus().toggleUnderline().run());
  divider();
  tool('bullet', 'Liste à puces', () => editor.chain().focus().toggleBulletList().run());
  tool('number', 'Liste numérotée', () => editor.chain().focus().toggleOrderedList().run());
  tool('quote', 'Citation', () => editor.chain().focus().toggleBlockquote().run());
  tool('divider', 'Insérer un séparateur', () => editor.chain().focus().setHorizontalRule().run());
  divider();
  tool('link', 'Insérer ou modifier un lien · ⌘/Ctrl K', openLink);
  tool('image', 'Ajouter une image · 100 Mo maximum', () => openPicker('image/*'), 'Image');
  tool('video', 'Ajouter une vidéo · 100 Mo maximum', () => openPicker('video/*'), 'Vidéo');
  tool('file', 'Joindre un fichier · 100 Mo maximum', () => openPicker(''), 'Fichier');
  divider();
  tool('undo', 'Annuler · ⌘/Ctrl Z', () => editor.chain().focus().undo().run());
  tool('redo', 'Rétablir · ⌘/Ctrl ⇧ Z', () => editor.chain().focus().redo().run());

  const linkForm = element('form', 'if-rich-link-form');
  linkForm.hidden = true;
  const urlLabel = element('label', '', 'Adresse du lien');
  const urlInput = element('input'); urlInput.type = 'text'; urlInput.inputMode = 'url'; urlInput.placeholder = 'https://…'; urlInput.autocomplete = 'off'; urlInput.spellcheck = false;
  urlLabel.append(urlInput);
  const textLabel = element('label', '', 'Texte affiché');
  const textInput = element('input'); textInput.type = 'text'; textInput.placeholder = 'Nom du lien'; textLabel.append(textInput);
  const linkActions = element('div', 'if-rich-link-actions');
  const applyLink = element('button', 'if-rich-link-apply', 'Insérer'); applyLink.type = 'submit';
  const cancelLink = element('button', '', 'Annuler'); cancelLink.type = 'button';
  const removeLink = element('button', '', 'Retirer le lien'); removeLink.type = 'button';
  const openLinkAnchor = element('a', '', 'Ouvrir ↗'); openLinkAnchor.target = '_blank'; openLinkAnchor.rel = 'noopener noreferrer'; openLinkAnchor.hidden = true;
  linkActions.append(applyLink, cancelLink, removeLink, openLinkAnchor);
  const linkError = element('p', 'if-rich-link-error'); linkError.hidden = true; linkError.setAttribute('role', 'alert');
  linkForm.append(urlLabel, textLabel, linkActions, linkError);
  const surface = element('div', 'if-rich-surface');
  const status = element('p', 'if-rich-status', 'Glisse tes images, vidéos ou fichiers ici · 100 Mo par fichier · conservés dans ce navigateur.');
  status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  const fileInput = element('input', 'if-rich-file-input'); fileInput.type = 'file'; fileInput.multiple = true; fileInput.hidden = true;
  host.append(toolbar, linkForm, surface, status, fileInput);

  function notify(message, isError = false) {
    if (destroyed) return;
    status.textContent = message; status.classList.toggle('is-error', isError);
    try { onStatus(message); } catch {}
  }
  function captureBookmark(selection = editor.state.selection) {
    const entry = { bookmark: selection.getBookmark() };
    bookmarks.add(entry);
    return entry;
  }
  function resolveBookmark(entry) {
    try { return entry.bookmark.resolve(editor.state.doc); } catch { return editor.state.selection; }
  }
  function syncToolbar() {
    if (!editor || destroyed) return;
    const active = { bold: 'bold', italic: 'italic', underline: 'underline', bullet: 'bulletList', number: 'orderedList', quote: 'blockquote', link: 'link' };
    for (const [id, mark] of Object.entries(active)) buttons[id].setAttribute('aria-pressed', String(editor.isActive(mark)));
    blockSelect.value = [1, 2, 3].find(level => editor.isActive('heading', { level })) ? `h${editor.getAttributes('heading').level}` : 'paragraph';
    buttons.undo.disabled = !editor.can().undo(); buttons.redo.disabled = !editor.can().redo();
  }
  function updateLinkPreview() {
    const href = safeLink(urlInput.value);
    openLinkAnchor.hidden = !href;
    if (href) openLinkAnchor.href = href; else openLinkAnchor.removeAttribute('href');
    linkError.hidden = true; urlInput.removeAttribute('aria-invalid');
  }
  function openLink() {
    if (!linkForm.hidden) { closeLink(); return; }
    if (editor.isActive('link')) editor.commands.extendMarkRange('link');
    linkBookmark = captureBookmark();
    const selection = editor.state.selection;
    urlInput.value = editor.getAttributes('link').href || '';
    textInput.value = editor.state.doc.textBetween(selection.from, selection.to, ' ');
    textInput.dataset.original = textInput.value;
    applyLink.textContent = urlInput.value ? 'Appliquer' : 'Insérer';
    removeLink.hidden = !editor.isActive('link');
    linkForm.hidden = false; updateLinkPreview(); urlInput.focus();
  }
  function closeLink(restoreFocus = true) {
    if (linkBookmark) {
      if (restoreFocus && !destroyed) { const selected = resolveBookmark(linkBookmark); editor.chain().focus().setTextSelection({ from: selected.from, to: selected.to }).run(); }
      bookmarks.delete(linkBookmark); linkBookmark = null;
    }
    linkForm.hidden = true;
  }
  function openPicker(accept) {
    if (pickerBookmark) bookmarks.delete(pickerBookmark);
    pickerBookmark = captureBookmark();
    fileInput.accept = accept; fileInput.value = ''; fileInput.click();
  }
  function uploadFiles(files, bookmark = captureBookmark()) {
    const list = Array.from(files || []);
    if (!list.length) { bookmarks.delete(bookmark); return; }
    importQueue = importQueue.then(async () => {
      if (destroyed) return;
      const nodes = [], errors = [];
      for (const file of list) {
        if (destroyed) break;
        const name = file.name || 'Fichier joint';
        if (file.size > MAX_FILE_SIZE) { errors.push(`${name} dépasse la limite de 100 Mo.`); continue; }
        if (!file.size) { errors.push(`${name} est vide.`); continue; }
        notify(`Ajout de ${name}…`);
        try {
          const record = await storeAsset(file);
          if (destroyed) break;
          nodes.push({ type: 'mediaAsset', attrs: { assetId: record.id, kind: mediaKind(record.mime), name: record.name, mime: record.mime, size: record.size } });
        } catch (error) {
          errors.push(error?.name === 'QuotaExceededError' ? `Espace de stockage insuffisant : ${name} n’a pas été ajouté.` : `Impossible de conserver ${name} dans ce navigateur. Réessaie ou vérifie l’espace disponible.`);
        }
      }
      if (destroyed) return;
      if (nodes.length) {
        const pos = resolveBookmark(bookmark).to;
        const inserted = editor.chain().command(({ tr }) => {
          closeHistory(tr);
          return true;
        }).insertContentAt(pos, [...nodes, { type: 'paragraph' }], { updateSelection: false }).run();
        if (!inserted) errors.push('Le fichier est conservé, mais son insertion a échoué. Réessaie dans un paragraphe.');
      }
      notify(errors.length ? errors.join(' ') : `${nodes.length > 1 ? `${nodes.length} fichiers ajoutés` : 'Fichier ajouté'} au document.`, Boolean(errors.length));
    }).catch(() => notify('L’ajout a échoué. Réessaie dans un paragraphe du document.', true)).finally(() => bookmarks.delete(bookmark));
  }

  editor = new Editor({
    element: surface,
    content: lastJSON,
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
        link: {
          openOnClick: false, enableClickSelection: true, defaultProtocol: 'https',
          HTMLAttributes: { target: '_blank', rel: 'noopener noreferrer' },
          isAllowedUri: url => Boolean(safeLink(url)),
        },
        dropcursor: { color: '#13945b', width: 2 },
      }),
      Placeholder.configure({ placeholder: 'Écris ton brief librement…' }),
      MediaAsset,
    ],
    editorProps: {
      attributes: { class: 'if-rich-content', 'aria-label': 'Contenu du brief', 'aria-multiline': 'true', role: 'textbox', spellcheck: 'true' },
      handlePaste(view, event) {
        const files = Array.from(event.clipboardData?.files || []);
        if (!files.length) return false;
        event.preventDefault(); uploadFiles(files); return true;
      },
      handleDrop(view, event, _slice, moved) {
        const files = Array.from(event.dataTransfer?.files || []);
        if (moved || !files.length) return false;
        event.preventDefault();
        const coordinates = view.posAtCoords({ left: event.clientX, top: event.clientY });
        const selection = coordinates ? TextSelection.near(view.state.doc.resolve(coordinates.pos)) : view.state.selection;
        uploadFiles(files, captureBookmark(selection)); return true;
      },
      handleClick(_view, _pos, event) {
        if (!(event.metaKey || event.ctrlKey)) return false;
        const href = safeLink(event.target.closest?.('a')?.getAttribute('href'));
        if (!href) return false;
        event.preventDefault(); window.open(href, '_blank', 'noopener,noreferrer'); return true;
      },
    },
    onTransaction({ transaction }) {
      if (transaction.docChanged) for (const entry of bookmarks) entry.bookmark = entry.bookmark.map(transaction.mapping);
      syncToolbar();
    },
    onSelectionUpdate: syncToolbar,
    onUpdate({ editor: current }) {
      if (destroyed) return;
      lastJSON = current.getJSON();
      onChange(lastJSON);
    },
  });

  blockSelect.addEventListener('change', () => {
    if (blockSelect.value === 'paragraph') editor.chain().focus().setParagraph().run();
    else editor.chain().focus().setHeading({ level: Number(blockSelect.value.slice(1)) }).run();
  });
  urlInput.addEventListener('input', updateLinkPreview);
  cancelLink.addEventListener('click', () => closeLink());
  removeLink.addEventListener('click', () => {
    if (!linkBookmark) return;
    const range = resolveBookmark(linkBookmark);
    editor.chain().focus().setTextSelection({ from: range.from, to: range.to }).unsetLink().run();
    closeLink();
  });
  linkForm.addEventListener('submit', event => {
    event.preventDefault();
    const href = safeLink(urlInput.value);
    if (!href) { linkError.textContent = 'Utilise une adresse https://, http:// ou mailto: valide.'; linkError.hidden = false; urlInput.setAttribute('aria-invalid', 'true'); urlInput.focus(); return; }
    if (!linkBookmark) return;
    const range = resolveBookmark(linkBookmark);
    const text = textInput.value.trim() || href;
    if (!range.empty && textInput.value === textInput.dataset.original) editor.chain().focus().setTextSelection({ from: range.from, to: range.to }).setLink({ href }).run();
    else editor.chain().focus().insertContentAt({ from: range.from, to: range.to }, { type: 'text', text, marks: [{ type: 'link', attrs: { href, target: '_blank', rel: 'noopener noreferrer' } }] }).command(({ tr }) => {
      // unsetLink() would also remove the link just inserted at this cursor.
      tr.removeStoredMark(editor.schema.marks.link);
      return true;
    }).run();
    closeLink(false);
  });
  fileInput.addEventListener('change', () => {
    if (destroyed) return;
    const bookmark = pickerBookmark || captureBookmark(); pickerBookmark = null;
    if (!destroyed) { editor.commands.focus(); uploadFiles(fileInput.files, bookmark); }
    fileInput.value = '';
  });
  fileInput.addEventListener('cancel', () => {
    if (pickerBookmark) bookmarks.delete(pickerBookmark);
    pickerBookmark = null;
    if (!destroyed) editor.commands.focus();
  });
  const keyHandler = event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); event.stopPropagation(); openLink(); }
    if (event.key === 'Escape' && !linkForm.hidden) { event.preventDefault(); event.stopPropagation(); closeLink(); }
  };
  host.addEventListener('keydown', keyHandler);
  syncToolbar();
  const instance = {
    destroy() {
      if (destroyed) return;
      lastJSON = editor.getJSON(); destroyed = true; bookmarks.clear();
      host.removeEventListener('keydown', keyHandler);
      editor.destroy();
      if (mounted.get(host) === instance) mounted.delete(host);
    },
    focus() { if (!destroyed) editor.commands.focus(); },
    getJSON() { return destroyed ? lastJSON : editor.getJSON(); },
  };
  mounted.set(host, instance);
  return instance;
}

window.IconFlowRichEditor = Object.freeze({ mount, plainTextDoc });
