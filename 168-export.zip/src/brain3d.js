import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { particleNetwork, particleObject, createParticleCanvas } from './brain-particles.js';
import './spacefield.js';
import { visualWatchdog } from './brain-visual-state.js';

let active = null;
let webglUnavailable = false;
const models = new Map();
const cachedGeometries = new WeakSet();
const cachedMaterials = new WeakSet();
const cachedTextures = new WeakSet();
const now = () => performance.now();
const modelURL = software => software
  ? (window.ICONFLOW_BRAIN_SOFTWARE_MODEL_URL || 'assets/brain-anatomical-software.glb')
  : (window.ICONFLOW_BRAIN_MODEL_URL || 'assets/brain-anatomical-lite.glb');

// One parsed model per quality level. View instances clone transforms and share immutable buffers.
function loadModel(url) {
  if (!models.has(url)) {
    const promise = new GLTFLoader().loadAsync(url).then(gltf => {
      gltf.scene.traverse(object => {
        if (object.geometry) cachedGeometries.add(object.geometry);
        for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
          if (!material) continue;
          cachedMaterials.add(material);
          for (const value of Object.values(material)) if (value?.isTexture) cachedTextures.add(value);
        }
      });
      return gltf.scene;
    });
    models.set(url, promise);
    // Preloads may complete before any view is mounted; failures are surfaced by that view.
    promise.catch(() => {});
  }
  return models.get(url);
}

function disposeObject(root) {
  if (!root) return;
  const geometries = new Set(), materials = new Set(), textures = new Set();
  root.traverse(object => {
    if (object.geometry && !cachedGeometries.has(object.geometry)) geometries.add(object.geometry);
    for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
      if (!material || cachedMaterials.has(material)) continue;
      materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture && !cachedTextures.has(value)) textures.add(value);
    }
    object.shadow?.dispose();
  });
  geometries.forEach(value => value.dispose());
  materials.forEach(value => value.dispose());
  textures.forEach(value => value.dispose());
}

function lightScene(scene) {
  scene.add(new THREE.HemisphereLight(0xc9f1d8, 0x102a17, 1.05));
  const key = new THREE.DirectionalLight(0xe2ffe9, 2.7);
  key.position.set(-3, 4.5, 4);
  key.castShadow = true;
  key.shadow.mapSize.set(512, 512);
  Object.assign(key.shadow.camera, { left: -1.4, right: 1.4, top: 1.4, bottom: -1.4, near: .5, far: 12 });
  key.shadow.bias = -.0003;
  key.shadow.normalBias = .012;
  scene.add(key);
  const rim = new THREE.DirectionalLight(0xa8ff70, 2.8);
  rim.position.set(3, 2, -3);
  scene.add(rim);
  const fill = new THREE.DirectionalLight(0x63ba84, .65);
  fill.position.set(3, -1, 3);
  scene.add(fill);
}

function mount(host) {
  if (host && active?.host === host && host.isConnected) return active;
  active?.dispose();
  if (!host) return;
  const stage = host.closest('.brain-map');
  if (!stage) return;
  const status = stage.querySelector('.brain-loading');
  const hint = stage.querySelector('.brain-interaction-hint');
  const events = new AbortController();
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const coarse = matchMedia('(pointer: coarse)').matches;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(34, 1, .05, 60);
  const initialDirection = new THREE.Vector3(2.6, 1, 3.2).normalize();
  const target = new THREE.Vector3(0, .02, 0);
  camera.position.copy(initialDirection.clone().multiplyScalar(5));
  let renderer, controls, model, mode = webglUnavailable ? 'software' : 'webgl';
  let disposed = false, loaded = false, firstFrame = false, generation = 0;
  let frame = 0, previous = 0, frames = 0, sampleFrames = 0, sampleStart = now();
  let inView = true, dirty = true, forceFrame = true, rotating = !motion.matches;
  let resizeObserver, intersectionObserver, watchdog;
  let fallbackActive = false;
  const started = now();
  lightScene(scene);
  host.hidden = false;
  stage.dataset.renderState = 'loading';
  host.dataset.renderer = mode;
  host.dataset.frames = '0';
  host.dataset.firstFrame = 'false';
  stage.dataset.rotation = rotating ? 'running' : 'paused';

  function showLoading() {
    stage.dataset.renderState = 'loading';
    if (status) {
      status.hidden = false;
      status.innerHTML = '<span class="brain-loader"></span><strong>Ton Brain prend forme…</strong>';
    }
    if (hint) { hint.hidden=false;hint.textContent = 'Glisse pour explorer'; }
    watchdog?.start();
  }
  function showError(kind, error) {
    if (disposed || fallbackActive) return;
    console.error(`IconFlow Brain: ${kind}.`, error);
    watchdog.fail(kind);
  }
  function requestFrame() {
    if (!frame && !disposed && loaded && !document.hidden && inView) frame = requestAnimationFrame(animate);
  }
  function schedule() {
    cancelAnimationFrame(frame); frame = 0; previous = 0;
    dirty = true; forceFrame = true;
    requestFrame();
  }
  function markReady() {
    if (firstFrame || fallbackActive || !watchdog.ready()) return;
    firstFrame = true;
    stage.dataset.renderState = 'ready';
    host.dataset.firstFrame = 'true';
    host.dataset.firstFrameMs = String(Math.round(now() - started));
    delete host.dataset.error;
    if (status) status.hidden = true;
  }
  function animate(time) {
    frame = 0;
    if (disposed || !loaded || document.hidden || !inView) return;
    const delta = previous ? Math.min((time - previous) / 1000, .05) : 0;
    previous = time;
    const changed = controls?.update(delta) || false;
    if (changed || dirty || rotating) {
      const renderStart = now();
      let rendered = false;
      try {
        if (mode === 'software') rendered = renderer.render(camera, time, forceFrame);
        else { renderer.render(scene, camera); rendered = true; }
      } catch (error) {
        if (mode === 'webgl') { useSoftware(error, 'webgl-render'); return; }
        showError('software-render', error); return;
      }
      if (rendered) {
        frames++; sampleFrames++;
        dirty = false; forceFrame = false;
        host.dataset.frames = String(frames);
        host.dataset.lastFrameMs = (now() - renderStart).toFixed(1);
        host.dataset.azimuth = (controls?.getAzimuthalAngle() || 0).toFixed(3);
        markReady();
      } else dirty = true;
    }
    if (time - sampleStart >= 1000) {
      host.dataset.fps = (sampleFrames * 1000 / (time - sampleStart)).toFixed(1);
      sampleStart = time; sampleFrames = 0;
    }
    if (rotating || changed || dirty) requestFrame();
  }
  function fitCamera(reset = false) {
    if (!renderer) return;
    const { width, height } = host.getBoundingClientRect();
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    const ratio = Math.min(devicePixelRatio || 1, mode === 'software' ? 1.25 : coarse ? 1.25 : 1.5);
    renderer.setPixelRatio(ratio);
    renderer.setSize(width, height, mode === 'software' ? ratio : false);
    const vertical = THREE.MathUtils.degToRad(camera.fov);
    const horizontal = 2 * Math.atan(Math.tan(vertical / 2) * camera.aspect);
    const distance = .96 / Math.sin(Math.min(vertical, horizontal) / 2) * (width < 500 ? 1.34 : 1.04);
    const direction = reset ? initialDirection.clone() : camera.position.clone().sub(target).normalize();
    camera.position.copy(direction.multiplyScalar(distance).add(target));
    if (controls) {
      controls.minDistance = distance * .76;
      controls.maxDistance = distance * 1.35;
      controls.update(0);
    }
    dirty = true; forceFrame = true;
    requestFrame();
  }
  function attachControls(canvas) {
    canvas.setAttribute('aria-label', 'Cerveau vert en points et connexions. Fais glisser pour le tourner, ou utilise les flèches du clavier.');
    canvas.setAttribute('role', 'img'); canvas.tabIndex = 0;
    controls = new OrbitControls(camera, canvas);
    controls.enableDamping = true; controls.dampingFactor = .075;
    controls.enablePan = false; controls.enableZoom = false;
    controls.rotateSpeed = .6; controls.autoRotateSpeed = .8;
    controls.minPolarAngle = .3; controls.maxPolarAngle = Math.PI - .3;
    controls.target.copy(target); controls.autoRotate = rotating;
    controls.addEventListener('change', () => { dirty = true; requestFrame(); });
    canvas.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      event.preventDefault();
      const spherical = new THREE.Spherical().setFromVector3(camera.position.clone().sub(target));
      if (event.key === 'ArrowLeft') spherical.theta -= .12;
      if (event.key === 'ArrowRight') spherical.theta += .12;
      if (event.key === 'ArrowUp') spherical.phi = Math.max(.3, spherical.phi - .12);
      if (event.key === 'ArrowDown') spherical.phi = Math.min(Math.PI - .3, spherical.phi + .12);
      camera.position.copy(new THREE.Vector3().setFromSpherical(spherical).add(target));
      controls.update(0); dirty = true; requestFrame();
    }, { signal: events.signal });
  }
  function releaseRenderer() {
    controls?.dispose(); controls = null;
    if (renderer) {
      renderer.dispose();
      renderer.forceContextLoss?.();
      renderer = null;
    }
    host.replaceChildren();
  }
  function makeWebGL() {
    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'default' });
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1;
    renderer.shadowMap.enabled = !coarse;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    const canvas = renderer.domElement;
    host.append(canvas); attachControls(canvas);
    canvas.addEventListener('webglcontextlost', event => {
      event.preventDefault();
      if (!disposed && mode === 'webgl') useSoftware(new Error('WebGL context lost'), 'webgl-context-lost');
    }, { signal: events.signal });
    fitCamera(true);
  }
  function useSoftware(error, reason) {
    if (disposed || fallbackActive || mode === 'software') return;
    webglUnavailable = true;
    console.warn(`IconFlow Brain: ${reason}; passage au rendu 3D logiciel.`, error);
    loaded = false; firstFrame = false;
    cancelAnimationFrame(frame); frame = 0;
    // Change mode before releasing the old context, whose loss event may still fire.
    mode = 'software'; releaseRenderer();
    host.dataset.renderer = mode; host.dataset.fallbackReason = reason;
    host.dataset.firstFrame = 'false';
    showLoading();
    loadForMode('software', false);
  }
  async function loadForMode(nextMode, resetCamera) {
    const ticket = ++generation;
    const loadStarted = now();
    let template;
    try { template = await loadModel(modelURL(nextMode === 'software')); }
    catch (error) { if (!disposed && ticket === generation) showError('model-load', error); return; }
    if (disposed || ticket !== generation) return;
    host.dataset.loadMs = String(Math.round(now() - loadStarted));
    if (model) { scene.remove(model); disposeObject(model); }
    model = template.clone(true);
    model.updateMatrixWorld(true);
    const network=particleNetwork(model,{maxPoints:coarse?1800:2600,maxEdges:coarse?3000:4800});
    host.dataset.points=String(network.pointCount);host.dataset.connections=String(network.edgeCount);host.dataset.style='particles';
    if (nextMode === 'webgl') {
      model=particleObject(network);scene.add(model);
    } else {
      try {
        renderer=createParticleCanvas({host,network,maxFps:30,pixelRatioCap:1.25});
        attachControls(renderer.canvas);
        host.dataset.triangles='0';
      } catch(error){showError('software-init',error);return;}
    }
    host.dataset.meshes = String(model.children.filter(child => child.isMesh).length);
    fitCamera(resetCamera);
    controls.saveState();
    loaded = true; dirty = true; forceFrame = true;
    schedule();
  }
  function onMotionChange() {
    rotating = !motion.matches;
    if (controls) controls.autoRotate = rotating;
    stage.dataset.rotation = rotating ? 'running' : 'paused';
    schedule();
  }
  function dispose() {
    if (disposed) return;
    disposed = true; generation++;
    watchdog?.dispose();
    cancelAnimationFrame(frame); frame = 0;
    events.abort(); resizeObserver?.disconnect(); intersectionObserver?.disconnect();
    motion.removeEventListener('change', onMotionChange);
    releaseRenderer();
    // GPU shadows/materials belong to the view; cached GLB geometry belongs to the session.
    disposeObject(scene);
    if (model && model.parent !== scene) disposeObject(model);
    if (active?.host === host) active = null;
  }
  watchdog = visualWatchdog({stage,host,status,hint,onFallback(reason){
    fallbackActive=true;generation++;loaded=false;
    host.dataset.error=reason;
    cancelAnimationFrame(frame);frame=0;
    resizeObserver?.disconnect();intersectionObserver?.disconnect();
    // Invalidate late model loads before releasing the canvas/context.
    try { releaseRenderer(); } catch(error) { console.warn('IconFlow Brain: nettoyage du visuel indisponible.',error); }
  }});
  active = { host, dispose };
  showLoading();
  // Start network + parsing before GPU initialization, with no PMREM shader generation.
  loadModel(modelURL(mode === 'software'));
  document.addEventListener('visibilitychange', schedule, { signal: events.signal });
  motion.addEventListener('change', onMotionChange);
  resizeObserver = new ResizeObserver(() => fitCamera()); resizeObserver.observe(host);
  intersectionObserver = new IntersectionObserver(entries => { inView = entries[0]?.isIntersecting ?? true; schedule(); }, { threshold: 0 });
  intersectionObserver.observe(host);
  if (mode === 'webgl') {
    try { makeWebGL(); loadForMode('webgl', true); }
    catch (error) { useSoftware(error, 'webgl-init'); }
  } else loadForMode('software', true);
  return active;
}

function preload() {
  const page = location.hash.slice(1);
  if (!['', 'overview', 'brain', 'brand'].includes(page)) return;
  return loadModel(modelURL(webglUnavailable)).catch(() => {});
}
window.IconFlowBrain3D = { mount, dispose: () => active?.dispose(), preload };
preload();
