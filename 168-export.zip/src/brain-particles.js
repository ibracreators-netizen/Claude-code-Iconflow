import * as THREE from 'three';

// Deterministic samples of the existing anatomical model: no opaque surface.
export function particleNetwork(root,{maxPoints=2600,cellSize=.035,maxEdges=4800}={}){
 const points=[],occupied=new Set(),v=new THREE.Vector3();root.updateMatrixWorld(true);
 root.traverse(mesh=>{if(!mesh.isMesh||!mesh.geometry?.attributes.position)return;const p=mesh.geometry.attributes.position;const stride=Math.max(1,Math.floor(p.count/14000));for(let i=0;i<p.count;i+=stride){v.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld);if(!Number.isFinite(v.x+v.y+v.z))continue;const key=[v.x,v.y,v.z].map(n=>Math.round(n/cellSize)).join(':');if(occupied.has(key))continue;occupied.add(key);points.push([v.x,v.y,v.z]);}});
 if(points.length>maxPoints){const sampled=[];for(let i=0;i<maxPoints;i++)sampled.push(points[Math.floor(i*points.length/maxPoints)]);points.splice(0,points.length,...sampled);}
 const edges=[],edgeSet=new Set(),radius=.15,grid=new Map(),bucket=p=>p.map(n=>Math.floor(n/radius));
 points.forEach((p,i)=>{const key=bucket(p).join(':');if(!grid.has(key))grid.set(key,[]);grid.get(key).push(i);});
 points.forEach((p,i)=>{const b=bucket(p),near=[];for(let x=-1;x<=1;x++)for(let y=-1;y<=1;y++)for(let z=-1;z<=1;z++)for(const j of grid.get([b[0]+x,b[1]+y,b[2]+z].join(':'))||[]){if(i===j)continue;const q=points[j],d=(p[0]-q[0])**2+(p[1]-q[1])**2+(p[2]-q[2])**2;if(d<radius*radius&&d>.00005)near.push([d,j]);}near.sort((a,b)=>a[0]-b[0]);for(const [,j]of near.slice(0,i%7===0?3:2)){const key=Math.min(i,j)+':'+Math.max(i,j);if(!edgeSet.has(key)&&edges.length<maxEdges){edgeSet.add(key);edges.push([i,j]);}}});
 if(points.length<10)throw new Error('Le modèle du Brain ne contient pas assez de points.');
 return {positions:new Float32Array(points.flat()),edges:new Uint16Array(edges.flat()),pointCount:points.length,edgeCount:edges.length};
}
export function particleObject(network){
 const root=new THREE.Group(),geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(network.positions,3));
 const sprite=document.createElement('canvas');sprite.width=sprite.height=32;const c=sprite.getContext('2d');c.fillStyle='#fff';c.beginPath();c.arc(16,16,13,0,Math.PI*2);c.fill();const texture=new THREE.CanvasTexture(sprite);
 root.add(new THREE.Points(geometry,new THREE.PointsMaterial({color:0x28733e,size:.018,map:texture,transparent:true,opacity:.82,alphaTest:.1,depthWrite:false,sizeAttenuation:true})));
 const linePositions=new Float32Array(network.edges.length*3);for(let i=0;i<network.edges.length;i++)for(let axis=0;axis<3;axis++)linePositions[i*3+axis]=network.positions[network.edges[i]*3+axis];const lines=new THREE.BufferGeometry();lines.setAttribute('position',new THREE.BufferAttribute(linePositions,3));root.add(new THREE.LineSegments(lines,new THREE.LineBasicMaterial({color:0x3b8d51,transparent:true,opacity:.18,depthWrite:false})));
 return root;
}
export function createParticleCanvas({host,network,maxFps=30,pixelRatioCap=1.25}){
 const canvas=document.createElement('canvas'),context=canvas.getContext('2d',{alpha:true});if(!context)throw new Error('Canvas 2D indisponible.');host.append(canvas);canvas.style.display='block';canvas.style.touchAction='none';let width=1,height=1,ratio=1,last=-Infinity,disposed=false;const matrix=new THREE.Matrix4(),v=new THREE.Vector3(),projected=new Float32Array(network.pointCount*3);
 function setSize(w,h,nextRatio=ratio){ratio=Math.min(pixelRatioCap,Math.max(1,nextRatio||1));width=Math.max(1,w);height=Math.max(1,h);const pixelWidth=Math.round(width*ratio),pixelHeight=Math.round(height*ratio);if(canvas.width!==pixelWidth||canvas.height!==pixelHeight){canvas.width=pixelWidth;canvas.height=pixelHeight;}canvas.style.width=width+'px';canvas.style.height=height+'px';last=-Infinity;}
 function render(camera,time,force=false){if(disposed||!force&&time-last<1000/maxFps)return false;last=time;camera.updateMatrixWorld(true);matrix.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);context.setTransform(ratio,0,0,ratio,0,0);context.clearRect(0,0,width,height);for(let i=0;i<network.pointCount;i++){v.fromArray(network.positions,i*3).applyMatrix4(matrix);projected[i*3]=(v.x+1)*width/2;projected[i*3+1]=(1-v.y)*height/2;projected[i*3+2]=v.z;}
 context.strokeStyle='rgba(50,125,70,.16)';context.lineWidth=.65;context.beginPath();for(let i=0;i<network.edges.length;i+=2){const a=network.edges[i]*3,b=network.edges[i+1]*3;if(Math.abs(projected[a+2])>=1||Math.abs(projected[b+2])>=1)continue;context.moveTo(projected[a],projected[a+1]);context.lineTo(projected[b],projected[b+1]);}context.stroke();
 for(let i=0;i<network.pointCount;i++){const o=i*3;if(Math.abs(projected[o+2])>=1)continue;context.fillStyle=i%13===0?'rgba(33,110,53,.95)':'rgba(43,124,65,.67)';context.beginPath();context.arc(projected[o],projected[o+1],i%13===0?1.65:1.05,0,Math.PI*2);context.fill();}return true;}
 return {canvas,pointCount:network.pointCount,triangleCount:0,setSize,setPixelRatio:next=>setSize(width,height,next),render,dispose(){disposed=true;canvas.remove();}};
}
