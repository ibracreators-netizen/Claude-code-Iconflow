import { Matrix3, Matrix4 } from 'three';

// CPU projection of the same anatomical triangle mesh, for browsers whose GPU
// renderer is disabled. No second animation loop or model ownership is created.
const KEY = normalize(-.45, .72, .63);
const FILL = normalize(.78, -.25, .62);
const RIM = normalize(.68, .38, -.65);
let palette;
const littleEndian = new Uint8Array(new Uint32Array([0x01020304]).buffer)[0] === 4;
function normalize(x, y, z) {
  const length = Math.hypot(x, y, z) || 1;
  return [x / length, y / length, z / length];
}
function colors() {
  if (palette) return palette;
  palette = new Uint32Array(512);
  for (let i = 0; i < palette.length; i++) {
    const light = i / 511 * 1.45;
    const sheen = Math.max(0, light - 1) * 20;
    const red = Math.min(255, Math.round(44 * light + sheen));
    const green = Math.min(255, Math.round(139 * light + sheen));
    const blue = Math.min(255, Math.round(77 * light + sheen));
    palette[i] = littleEndian ? (255 << 24) | (blue << 16) | (green << 8) | red : (red << 24) | (green << 16) | (blue << 8) | 255;
  }
  return palette;
}

function prepareMesh(mesh) {
  const geometry = mesh.geometry;
  const attribute = geometry?.getAttribute('position');
  if (!attribute || attribute.count < 3) return null;
  const normalAttribute = geometry.getAttribute('normal');
  const count = attribute.count;
  const positions = new Float32Array(count * 3);
  const normals = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const offset = i * 3;
    positions[offset] = attribute.getX(i);
    positions[offset + 1] = attribute.getY(i);
    positions[offset + 2] = attribute.getZ(i);
    if (normalAttribute) {
      normals[offset] = normalAttribute.getX(i);
      normals[offset + 1] = normalAttribute.getY(i);
      normals[offset + 2] = normalAttribute.getZ(i);
    }
  }
  const index = geometry.getIndex();
  const available = index ? index.count : count;
  const start = Math.max(0, geometry.drawRange.start || 0);
  const end = Math.min(available, start + (geometry.drawRange.count ?? Infinity));
  const faces = [];
  const curvature = new Float32Array(count);
  const neighbours = new Uint16Array(count);
  for (let offset = start; offset + 2 < end; offset += 3) {
    const a = index ? index.getX(offset) : offset;
    const b = index ? index.getX(offset + 1) : offset + 1;
    const c = index ? index.getX(offset + 2) : offset + 2;
    const ai = a * 3, bi = b * 3, ci = c * 3;
    const abx = positions[bi] - positions[ai], aby = positions[bi + 1] - positions[ai + 1], abz = positions[bi + 2] - positions[ai + 2];
    const acx = positions[ci] - positions[ai], acy = positions[ci + 1] - positions[ai + 1], acz = positions[ci + 2] - positions[ai + 2];
    const geometricNormal = normalize(aby * acz - abz * acy, abz * acx - abx * acz, abx * acy - aby * acx);
    const averagedNormal = normalAttribute ? normalize(normals[ai] + normals[bi] + normals[ci], normals[ai + 1] + normals[bi + 1] + normals[ci + 1], normals[ai + 2] + normals[bi + 2] + normals[ci + 2]) : geometricNormal;
    faces.push({
      a, b, c,
      gx: geometricNormal[0], gy: geometricNormal[1], gz: geometricNormal[2],
      nx: averagedNormal[0], ny: averagedNormal[1], nz: averagedNormal[2],
      ao: 1, depth: 0, color: '', clipped: null,
    });
    if (normalAttribute) {
      // Neighbours above the tangent plane identify a concave crease. This is a
      // local curvature cue, not screen-space AO, and remains stable on rotation.
      for (const [from, to] of [[a, b], [a, c], [b, a], [b, c], [c, a], [c, b]]) {
        const fi = from * 3, ti = to * 3;
        const dx = positions[ti] - positions[fi], dy = positions[ti + 1] - positions[fi + 1], dz = positions[ti + 2] - positions[fi + 2];
        const length = Math.hypot(dx, dy, dz);
        if (length > 1e-9) {
          curvature[from] += (dx * normals[fi] + dy * normals[fi + 1] + dz * normals[fi + 2]) / length;
          neighbours[from]++;
        }
      }
    }
  }
  const occlusion = new Float32Array(count);
  const smoothCurvature = new Float32Array(count);
  for (let i = 0; i < count; i++) curvature[i] = Math.max(0, curvature[i] / (neighbours[i] || 1));
  for (const face of faces) {
    smoothCurvature[face.a] += curvature[face.b] + curvature[face.c];
    smoothCurvature[face.b] += curvature[face.a] + curvature[face.c];
    smoothCurvature[face.c] += curvature[face.a] + curvature[face.b];
  }
  for (let i = 0; i < count; i++) {
    const concavity = .5 * curvature[i] + .5 * smoothCurvature[i] / (neighbours[i] || 1);
    occlusion[i] = 1 - Math.min(.18, concavity * .85);
  }
  if (!normalAttribute) {
    for (const face of faces) for (const vertex of [face.a, face.b, face.c]) {
      normals[vertex * 3] += face.gx; normals[vertex * 3 + 1] += face.gy; normals[vertex * 3 + 2] += face.gz;
    }
  }
  const result = { mesh, positions, normals, occlusion, shade: new Float32Array(count), faces, view: new Float32Array(count * 3), screen: new Float32Array(count * 2), matrix: new Matrix4(), normal: new Matrix3() };
  for (const face of faces) face.mesh = result;
  return result;
}

function visible(mesh, root) {
  let object = mesh;
  while (object) {
    if (!object.visible) return false;
    if (object === root) return true;
    object = object.parent;
  }
  return true;
}

// Sutherland–Hodgman clipping in view space. Near-plane intersections never
// reach perspective division, avoiding exploding triangles when the camera is close.
function clipDepth(points, plane, keepLess) {
  const result = [];
  let previous = points[points.length - 1];
  let wasInside = keepLess ? previous[2] <= plane : previous[2] >= plane;
  for (const current of points) {
    const inside = keepLess ? current[2] <= plane : current[2] >= plane;
    if (inside !== wasInside) {
      const t = (plane - previous[2]) / (current[2] - previous[2]);
      result.push([previous[0] + t * (current[0] - previous[0]), previous[1] + t * (current[1] - previous[1]), plane, previous[3] + t * (current[3] - previous[3])]);
    }
    if (inside) result.push(current);
    previous = current;
    wasInside = inside;
  }
  return result;
}

/**
 * @param {{host:HTMLElement, model:import('three').Object3D,
 * camera?:import('three').Camera, maxFps?:number, pixelRatioCap?:number}} options
 * Caller owns camera/OrbitControls/RAF and the glTF model. Use the dedicated
 * ~16k-triangle software GLB; this renderer keeps every face to avoid holes.
 */
export function createSoftwareBrain({ host, model, camera: initialCamera, maxFps = 30, pixelRatioCap = 1.25 }) {
  if (!host || !model?.traverse) throw new Error('A host and an anatomical model are required.');
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d', { alpha: true, desynchronized: true });
  if (!context) throw new Error('Canvas 2D is unavailable.');
  canvas.className = 'brain-software-canvas';
  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label', 'Cerveau anatomique en 3D. Faites glisser pour le tourner, ou utilisez les flèches du clavier.');
  canvas.tabIndex = 0;
  canvas.style.display = 'block';
  canvas.style.touchAction = 'none';
  const meshes = [];
  model.traverse(object => { if (object.isMesh) { const mesh = prepareMesh(object); if (mesh) meshes.push(mesh); } });
  const triangleCount = meshes.reduce((sum, mesh) => sum + mesh.faces.length, 0);
  if (!triangleCount) throw new Error('The anatomical model has no drawable triangles.');
  const lookup = colors();
  const faces = [];
  let disposed = false, width = 1, height = 1, cssWidth = 1, cssHeight = 1, ratio = 1, lastRender = -Infinity;
  let imageData = null, pixels = null, depthBuffer = null;
  const frameInterval = 1000 / Math.min(60, Math.max(1, maxFps));
  canvas.dataset.renderer = 'canvas2d';
  canvas.dataset.triangles = String(triangleCount);
  host.append(canvas);

  function setSize(nextWidth, nextHeight, nextRatio = ratio) {
    if (disposed) return;
    cssWidth = Math.max(1, Number(nextWidth) || 1);
    cssHeight = Math.max(1, Number(nextHeight) || 1);
    if (typeof nextRatio === 'number') ratio = Math.min(1.25, pixelRatioCap, Math.max(1, nextRatio || 1));
    // CSS keeps the full viewport. The CPU framebuffer has a fixed work budget,
    // independent of Retina density; browser scaling smooths its silhouette.
    const scale = Math.min(1, ratio, 1000 / cssWidth, 700 / cssHeight, Math.sqrt(600000 / (cssWidth * cssHeight)));
    const nextPixelsWide = Math.max(1, Math.round(cssWidth * scale));
    const nextPixelsHigh = Math.max(1, Math.round(cssHeight * scale));
    if (!imageData || width !== nextPixelsWide || height !== nextPixelsHigh) {
      width = nextPixelsWide; height = nextPixelsHigh;
      canvas.width = width; canvas.height = height;
      imageData = context.createImageData(width, height);
      pixels = new Uint32Array(imageData.data.buffer, imageData.data.byteOffset, width * height);
      depthBuffer = new Float32Array(width * height);
    }
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = cssHeight + 'px';
    canvas.dataset.renderResolution = width + 'x' + height;
    lastRender = -Infinity;
  }
  function setPixelRatio(value) { setSize(cssWidth, cssHeight, value); }

  // Scan conversion shades contiguous horizontal spans. Each pixel receives a
  // perspective-correct interpolated intensity and an actual depth test, so no
  // Canvas path/gradient commands or painter-order approximations are involved.
  function rasterTriangle(x0, y0, q0, s0, x1, y1, q1, s1, x2, y2, q2, s2, perspective) {
    const determinant = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (Math.abs(determinant) < 1e-7) return;
    const inverse = 1 / determinant;
    if (perspective) { s0 *= q0; s1 *= q1; s2 *= q2; }
    const qx = ((q1 - q0) * (y2 - y0) - (q2 - q0) * (y1 - y0)) * inverse;
    const qy = ((x1 - x0) * (q2 - q0) - (x2 - x0) * (q1 - q0)) * inverse;
    const qc = q0 - qx * x0 - qy * y0;
    const sx = ((s1 - s0) * (y2 - y0) - (s2 - s0) * (y1 - y0)) * inverse;
    const sy = ((x1 - x0) * (s2 - s0) - (x2 - x0) * (s1 - s0)) * inverse;
    const sc = s0 - sx * x0 - sy * y0;
    let swap;
    if (y0 > y1) { swap = y0; y0 = y1; y1 = swap; swap = x0; x0 = x1; x1 = swap; }
    if (y1 > y2) { swap = y1; y1 = y2; y2 = swap; swap = x1; x1 = x2; x2 = swap; }
    if (y0 > y1) { swap = y0; y0 = y1; y1 = swap; swap = x0; x0 = x1; x1 = swap; }
    const top = Math.max(0, Math.ceil(y0 - .5));
    const bottom = Math.min(height - 1, Math.ceil(y2 - .5) - 1);
    if (top > bottom || y2 - y0 < 1e-7) return;
    const longSlope = (x2 - x0) / (y2 - y0);
    const upperSlope = y1 > y0 ? (x1 - x0) / (y1 - y0) : 0;
    const lowerSlope = y2 > y1 ? (x2 - x1) / (y2 - y1) : 0;
    for (let y = top; y <= bottom; y++) {
      const py = y + .5;
      const longX = x0 + (py - y0) * longSlope;
      const shortX = py < y1 ? x0 + (py - y0) * upperSlope : x1 + (py - y1) * lowerSlope;
      const left = Math.max(0, Math.ceil(Math.min(longX, shortX) - .5));
      const right = Math.min(width - 1, Math.ceil(Math.max(longX, shortX) - .5) - 1);
      if (left > right) continue;
      let offset = y * width + left;
      let depth = qx * (left + .5) + qy * py + qc;
      let shade = sx * (left + .5) + sy * py + sc;
      for (let x = left; x <= right; x++, offset++, depth += qx, shade += sx) {
        if (depth > depthBuffer[offset]) {
          depthBuffer[offset] = depth;
          const value = perspective ? shade / depth : shade;
          const colorIndex = Math.max(0, Math.min(511, (value * (511 / 1.45) + .5) | 0));
          pixels[offset] = lookup[colorIndex];
        }
      }
    }
  }

  function render(camera = initialCamera, now = performance.now(), force = false) {
    if (disposed || !camera) return false;
    if (!imageData) setSize(cssWidth, cssHeight, ratio);
    if (!force && now >= lastRender && now - lastRender < frameInterval - .8) return false;
    lastRender = now;
    camera.updateMatrixWorld(true);
    model.updateWorldMatrix(true, true);
    const projection = camera.projectionMatrix.elements;
    const near = Math.max(1e-5, camera.near ?? .01), far = camera.far ?? Infinity;
    const halfWidth = width * .5, halfHeight = height * .5;
    faces.length = 0;
    for (const mesh of meshes) {
      if (!visible(mesh.mesh, model)) continue;
      mesh.matrix.multiplyMatrices(camera.matrixWorldInverse, mesh.mesh.matrixWorld);
      mesh.normal.getNormalMatrix(mesh.matrix);
      const matrix = mesh.matrix.elements, normal = mesh.normal.elements;
      const positions = mesh.positions, view = mesh.view, screen = mesh.screen, normals = mesh.normals, shade = mesh.shade;
      for (let i = 0, s = 0; i < positions.length; i += 3, s += 2) {
        const x = positions[i], y = positions[i + 1], z = positions[i + 2];
        const vx = matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12];
        const vy = matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13];
        const vz = matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14];
        view[i] = vx; view[i + 1] = vy; view[i + 2] = vz;
        const w = projection[3] * vx + projection[7] * vy + projection[11] * vz + projection[15];
        const inverseW = Math.abs(w) > 1e-8 ? 1 / w : 0;
        screen[s] = halfWidth + (projection[0] * vx + projection[4] * vy + projection[8] * vz + projection[12]) * inverseW * halfWidth;
        screen[s + 1] = halfHeight - (projection[1] * vx + projection[5] * vy + projection[9] * vz + projection[13]) * inverseW * halfHeight;
        // Shared vertex lighting makes both sides of every edge agree. A
        // pixel rasterizer interpolates this field across each projected triangle.
        let nx = normal[0] * normals[i] + normal[3] * normals[i + 1] + normal[6] * normals[i + 2];
        let ny = normal[1] * normals[i] + normal[4] * normals[i + 1] + normal[7] * normals[i + 2];
        let nz = normal[2] * normals[i] + normal[5] * normals[i + 1] + normal[8] * normals[i + 2];
        const inverseLength = 1 / (Math.hypot(nx, ny, nz) || 1);
        nx *= inverseLength; ny *= inverseLength; nz *= inverseLength;
        const inverseViewLength = 1 / (Math.hypot(vx, vy, vz) || 1);
        const eyeX = camera.isOrthographicCamera ? 0 : -vx * inverseViewLength;
        const eyeY = camera.isOrthographicCamera ? 0 : -vy * inverseViewLength;
        const eyeZ = camera.isOrthographicCamera ? 1 : -vz * inverseViewLength;
        const ndv = Math.max(0, Math.min(1, nx * eyeX + ny * eyeY + nz * eyeZ));
        const key = Math.max(0, nx * KEY[0] + ny * KEY[1] + nz * KEY[2]);
        const fill = Math.max(0, nx * FILL[0] + ny * FILL[1] + nz * FILL[2]);
        const rim = Math.max(0, nx * RIM[0] + ny * RIM[1] + nz * RIM[2]) * (1 - ndv);
        const hx = KEY[0] + eyeX, hy = KEY[1] + eyeY, hz = KEY[2] + eyeZ;
        const ndh = Math.max(0, (nx * hx + ny * hy + nz * hz) / (Math.hypot(hx, hy, hz) || 1));
        shade[i / 3] = (.29 + .09 * (ny * .5 + .5) + .82 * key + .17 * fill + .17 * rim + .045 * Math.pow(ndh, 16)) * mesh.occlusion[i / 3];
      }
      for (const face of mesh.faces) {
        const a = face.a * 3, b = face.b * 3, c = face.c * 3;
        const az = view[a + 2], bz = view[b + 2], cz = view[c + 2];
        if ((az > -near && bz > -near && cz > -near) || (az < -far && bz < -far && cz < -far)) continue;
        const cx = (view[a] + view[b] + view[c]) / 3;
        const cy = (view[a + 1] + view[b + 1] + view[c + 1]) / 3;
        const depth = (az + bz + cz) / 3;
        const gx = normal[0] * face.gx + normal[3] * face.gy + normal[6] * face.gz;
        const gy = normal[1] * face.gx + normal[4] * face.gy + normal[7] * face.gz;
        const gz = normal[2] * face.gx + normal[5] * face.gy + normal[8] * face.gz;
        if (camera.isOrthographicCamera ? gz <= 0 : gx * cx + gy * cy + gz * depth >= 0) continue;
        face.clipped = null;
        if (az > -near || bz > -near || cz > -near || az < -far || bz < -far || cz < -far) {
          let polygon = [[view[a], view[a + 1], az, shade[face.a]], [view[b], view[b + 1], bz, shade[face.b]], [view[c], view[c + 1], cz, shade[face.c]]];
          polygon = clipDepth(polygon, -near, true);
          if (polygon.length < 3) continue;
          if (Number.isFinite(far)) polygon = clipDepth(polygon, -far, false);
          if (polygon.length < 3) continue;
          face.clipped = polygon.map(([x, y, z, light]) => {
            const w = projection[3] * x + projection[7] * y + projection[11] * z + projection[15];
            return [halfWidth + (projection[0] * x + projection[4] * y + projection[8] * z + projection[12]) / w * halfWidth, halfHeight - (projection[1] * x + projection[5] * y + projection[9] * z + projection[13]) / w * halfHeight, light, camera.isOrthographicCamera ? z : -1 / z];
          });
        } else {
          const sa = face.a * 2, sb = face.b * 2, sc = face.c * 2;
          if ((screen[sa] < 0 && screen[sb] < 0 && screen[sc] < 0) || (screen[sa] > width && screen[sb] > width && screen[sc] > width) || (screen[sa + 1] < 0 && screen[sb + 1] < 0 && screen[sc + 1] < 0) || (screen[sa + 1] > height && screen[sb + 1] > height && screen[sc + 1] > height)) continue;
        }
        face.depth = depth;
        faces.push(face);
      }
    }
    pixels.fill(0);
    depthBuffer.fill(-Infinity);
    const perspective = !camera.isOrthographicCamera;
    for (const face of faces) {
      if (face.clipped) {
        const points = face.clipped;
        for (let i = 1; i + 1 < points.length; i++) {
          const a = points[0], b = points[i], c = points[i + 1];
          rasterTriangle(a[0], a[1], a[3], a[2], b[0], b[1], b[3], b[2], c[0], c[1], c[3], c[2], perspective);
        }
      } else {
        const screen = face.mesh.screen, view = face.mesh.view, shade = face.mesh.shade;
        const a = face.a, b = face.b, c = face.c;
        const az = view[a * 3 + 2], bz = view[b * 3 + 2], cz = view[c * 3 + 2];
        rasterTriangle(screen[a * 2], screen[a * 2 + 1], perspective ? -1 / az : az, shade[a], screen[b * 2], screen[b * 2 + 1], perspective ? -1 / bz : bz, shade[b], screen[c * 2], screen[c * 2 + 1], perspective ? -1 / cz : cz, shade[c], perspective);
      }
    }
    context.putImageData(imageData, 0, 0);
    canvas.dataset.visibleTriangles = String(faces.length);
    return true;
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    canvas.remove();
    canvas.width = 1; canvas.height = 1;
    faces.length = 0;
    meshes.length = 0;
    imageData = pixels = depthBuffer = null;
  }
  return { canvas, domElement: canvas, render, setSize, setPixelRatio, dispose, triangleCount };
}
