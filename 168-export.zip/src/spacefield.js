// A single, static 2D canvas for the entire Brain page. No animation loop or WebGL context.
let active = null;

function mount() {
  if (active?.canvas.isConnected) return active;
  active?.dispose();
  const canvas = document.createElement('canvas');
  canvas.className = 'brain-space-backdrop';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.setAttribute('aria-hidden', 'true');
  canvas.setAttribute('role', 'presentation');
  const context = canvas.getContext('2d', { alpha: false });
  if (!context) return null;
  const events = new AbortController();
  const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
  let disposed = false, dirty = true, timer = 0, frame = 0;
  let lastWidth = 0, lastHeight = 0, lastRatio = 0;
  document.body.append(canvas);

  function glow(x, y, rx, ry, angle, color, opacity) {
    context.save();
    context.translate(x, y);
    context.rotate(angle);
    context.scale(rx, ry);
    const gradient = context.createRadialGradient(0, 0, 0, 0, 0, 1);
    gradient.addColorStop(0, `rgba(${color},${opacity})`);
    gradient.addColorStop(.28, `rgba(${color},${opacity * .66})`);
    gradient.addColorStop(.62, `rgba(${color},${opacity * .21})`);
    gradient.addColorStop(1, `rgba(${color},0)`);
    context.fillStyle = gradient;
    context.fillRect(-1, -1, 2, 2);
    context.restore();
  }

  function draw() {
    frame = 0;
    if (disposed || document.hidden || !dirty) return;
    const width = Math.max(1, window.innerWidth);
    const height = Math.max(1, window.innerHeight);
    const ratio = Math.min(window.devicePixelRatio || 1, matchMedia('(pointer: coarse)').matches ? 1.25 : 1.5);
    if (width === lastWidth && height === lastHeight && ratio === lastRatio) {
      dirty = false;
      return;
    }
    lastWidth = width; lastHeight = height; lastRatio = ratio;
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    const background = context.createLinearGradient(0, 0, width, height);
    background.addColorStop(0, '#030806');
    background.addColorStop(.52, '#06110c');
    background.addColorStop(1, '#030908');
    context.fillStyle = background;
    context.fillRect(0, 0, width, height);

    // Broad clouds cross the viewport, including the gaps between cards and navigation.
    context.globalCompositeOperation = 'screen';
    glow(width * .66, height * .44, width * .69, height * .58, -.28, '12,79,42', .55);
    glow(width * .29, height * .80, width * .52, height * .43, -.48, '8,61,51', .43);
    glow(width * .97, height * .17, width * .31, height * .50, .2, '21,65,31', .34);
    for (let i = 0; i < 22; i++) {
      const t = i / 21;
      const x = width * (-.12 + t * 1.28);
      const y = height * (.63 - .29 * t + .09 * Math.sin(t * 7.3));
      const strength = .045 + .045 * Math.sin(t * Math.PI);
      glow(x, y, width * .16, height * (.055 + .035 * Math.sin(t * 8) ** 2), -.39, '31,114,66', strength);
      glow(x + width * .06, y + height * .15, width * .13, height * .065, -.3, '10,77,70', strength * .75);
    }
    context.globalCompositeOperation = 'source-over';

    // Deterministic coordinates prevent random reshuffling when the viewport resizes.
    let seed = 90217;
    const random = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
    const count = Math.max(260, Math.min(1550, Math.round(width * height / 1650)));
    for (let i = 0; i < count; i++) {
      const x = random() * width;
      const y = random() * height;
      const depth = random();
      const radius = .26 + Math.pow(depth, 4) * 1.07;
      const alpha = .19 + Math.pow(depth, 1.7) * .70;
      const color = random() > .26 ? '245,247,224' : '142,197,166';
      if (depth > .975) {
        glow(x, y, radius * 5, radius * 5, 0, '168,226,179', .2);
        context.strokeStyle = `rgba(211,242,207,${alpha * .23})`;
        context.lineWidth = .55;
        context.beginPath();
        context.moveTo(x - radius * 3, y); context.lineTo(x + radius * 3, y);
        context.moveTo(x, y - radius * 3); context.lineTo(x, y + radius * 3);
        context.stroke();
      }
      context.fillStyle = `rgba(${color},${alpha})`;
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.fill();
    }
    // A soft vignette leaves the cloud dimensional without creating a visible panel edge.
    const vignette = context.createRadialGradient(width * .58, height * .46, Math.min(width, height) * .24,
      width * .58, height * .46, Math.max(width, height) * .83);
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(1, 'rgba(0,0,0,.36)');
    context.fillStyle = vignette;
    context.fillRect(0, 0, width, height);
    canvas.dataset.renderState = 'ready';
    canvas.dataset.stars = String(count);
    dirty = false;
  }

  function schedule() {
    dirty = true;
    clearTimeout(timer);
    if (disposed || document.hidden) return;
    // Resize events are coalesced; there is never a background animation loop.
    timer = setTimeout(() => {
      if (!disposed && !document.hidden && !frame) frame = requestAnimationFrame(draw);
    }, 100);
  }
  function onVisibilityChange() {
    if (document.hidden) {
      clearTimeout(timer);
      cancelAnimationFrame(frame);
      frame = 0;
    } else if (dirty) {
      schedule();
    }
  }
  function onMotionChange() {
    // The backdrop is deliberately still in both modes, independent of the rotating Brain.
    canvas.dataset.motion = motionPreference.matches ? 'static-reduced' : 'static';
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    clearTimeout(timer);
    cancelAnimationFrame(frame);
    events.abort();
    motionPreference.removeEventListener('change', onMotionChange);
    canvas.remove();
    canvas.width = 1; canvas.height = 1;
    if (active?.canvas === canvas) active = null;
  }

  window.addEventListener('resize', schedule, { signal: events.signal, passive: true });
  window.visualViewport?.addEventListener('resize', schedule, { signal: events.signal, passive: true });
  document.addEventListener('visibilitychange', onVisibilityChange, { signal: events.signal });
  motionPreference.addEventListener('change', onMotionChange);
  active = { canvas, dispose };
  onMotionChange();
  draw();
  return active;
}

window.IconFlowSpace = { mount, dispose: () => active?.dispose() };
