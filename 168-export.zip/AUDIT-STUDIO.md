# Iconflow Studio — audit et changements du 28 octobre 2026

Audit de la source da27183aee551344b65a1c2a517e8123f9a94f69 avant modification. Aucune écriture de données métier, Auth, comptes, clients, politiques RLS ou migration SQL exécutée. Publication non demandée et non effectuée.

## Backend observé

Application statique. Auth et données connectées : Supabase xqacgjtlktzrmfcolbst.supabase.co, SDK supabase-js v2, signInWithPassword puis getUser et profiles(id,role,client_id). Tables : clients, briefs, avatars, livrables, validations, brand_dossiers. Classement agence : agency_client_management et RPC agency_save_client_management. Décisions scripts client : RPC client_decide_script. Import URL Brain : fonction brain-import-url.

La clé publique reste identique. La clé de session iconflow-supabase-test-auth-v1 est conservée malgré son ancien nom pour éviter de déconnecter les comptes existants. Aucune clé privilégiée utilisée. localStorage sert aussi à l’historique de recherche par compte/client. Les anciens enregistrements de démo ne sont ni migrés ni supprimés.

## Inventaire de démonstration

- auth-gate.js : bannière « Projet de démonstration · données fictives », aussi affichée aux vrais comptes ; lien « Continuer en démo locale » ; session locale persistante ; textes « PROJET DE TEST », « données de démonstration », erreurs de connexion et modales de test.
- routing.js : #demo était implicitement ramené à l’accueil ; désormais redirection vers #login, jamais accès local.
- app.js : faux assets Lashéa, Brain, personas, produits, questions, anciennes vues et actions locales.
- admin.js : registre local Lashéa, clients locaux, onboarding fictif, mentions prototype et données fictives.
- avatars.js, monthly-briefs.js, deliveries.js : anciens parcours locaux. Modules retirés du dossier servi et du HTML ; présentation connectée indépendante préservée.
- agency-board.js : adaptateur de démonstration et textes de notes locales retirés.
- index.html et dialogue À propos : mentions maquette/prototype retirées ; métadonnées nettoyées.
- Aucun Koya Paris trouvé dans la source ni dans les seeds versionnés. Les données Koya connectées n’ont pas été lues avec un compte authentifié, modifiées ou supprimées.
- Les documents historiques README et propositions SQL mentionnent encore les anciennes recettes TEST : ce sont des documents internes non affichés par l’application. Aucun SQL proposé n’a été appliqué.
- La description administrative Sites reste « Maquette interactive… » : inchangée pour ne pas modifier les métadonnées du site publié pendant une revue sans publication.

## Parcours : capacités et limites

| Parcours | Constat et changement | Vérification réelle restante |
|---|---|---|
| Connexion agence | Vrai Supabase Auth conservé ; arrivée par défaut sur Gestion des clients | Connexion ibra@iconflow.fr non effectuée : aucune session ou mot de passe disponible |
| Clients | Lecture/création/modification/archivage conditionnés au rôle agence ; aucune suppression définitive | Droits et contraintes réels de la base |
| Ouvrir espace | Fonctionnait depuis la liste seulement ; désormais disponible depuis la fiche ; identifiant décodé depuis la route | Navigation avec plusieurs clients réels |
| File de validation | Les briefs/livrables ouvrent maintenant l’écran métier du client sélectionné, avec les actions permises | Exécution des décisions réelles |
| Brain | Lecture brand_dossiers, saisie et import URL connectés préservés | Dossier Koya, accès/RLS et fonction d’import distante |
| Briefs | Calendrier, création, édition, corbeille/restauration et transitions conservés | Écritures réelles et RPC client_decide_script |
| Livrables | Lecture et validations conservées ; « Ajouter un lien » agence désormais fonctionnel : HTTPS, mois/type/titre, statut en_controle | INSERT permis par le schéma/RLS réel ; ouverture des médias |
| Avatars | Consultation et choix client conservés | Ajout d’avatars toujours indisponible : pas de téléversement/stockage connecté implémenté |
| Performance | État vide honnête, aucun chiffre inventé | Connexion aux données publicitaires absente |
| Client | Toutes les requêtes portent client_id ; refus de client étranger et routes agence ; profil vérifié côté Auth | Isolation serveur RLS non prouvée par inspection de la source ; nécessite deux comptes réels et audit des politiques |

Créer une fiche client n’invite personne et ne crée pas un compte Auth. L’affectation d’un compte client à son espace reste une opération backend existante ; aucun système d’invitation inventé.

Les transitions agence/validations livrables utilisent deux requêtes et peuvent échouer partiellement. Les erreurs sont affichées ; aucune nouvelle RPC transactionnelle n’a été installée. Le classement agence dépend d’une table et RPC préexistantes ; la liste client reste disponible si elles échouent.

## Données ambiguës conservées

Toutes les lignes Supabase, notamment tout client Koya, son Brain et ses créations, sont conservées sans filtrage par nom, titre ou mot « test ». Le nombre de 10 créations n’a pas été confirmé. Tous les anciens contenus navigateur sont laissés intacts mais ne sont plus chargés. Sans lecture authentifiée il n’est pas possible d’identifier d’autres clients ou lignes ambiguës.

## Interface et contrôle

Retour à l’identité sombre et verte en retirant la surcouche perle ; tailles, marges, formulaires, états vides français et focus clavier harmonisés. Recherche et fenêtres de dialogue conservées.

82 tests automatisés passent (contrôles de portée, droits, transitions, Brain, briefs, classement et création de liens). Trois tests obsolètes de l’adaptateur de démo retirés ; test ajout de livrable et vérification anti-démo ajoutés/mis à jour. Syntaxe des modules actifs vérifiée.

Navigateur : écran de connexion sombre inspecté, absence du lien/bannière démo confirmée, #demo redirige vers #login, service SDK chargé et bouton de connexion actif. Aucun parcours authentifié réel ni rendu visuel de l’admin connecté validé. Les tests utilisent des fixtures isolées et ne constituent pas une preuve d’accès au backend réel.
