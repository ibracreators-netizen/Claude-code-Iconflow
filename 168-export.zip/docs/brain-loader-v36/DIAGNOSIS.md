# Brain loader v36 — unpublished fix

## Confirmed source findings

Published v34 (da27183aee551344b65a1c2a517e8123f9a94f69) and saved v35 (26735fd8efc88e1bafa9e6c2f8be76acb79ab211) have byte-identical brain3d.bundle.js:
SHA-256 6c7676646ffde18fe721f6983072048dc10b3bf22133e6db8b3e6e5868ebaf90.

The old overlay is hidden only in markReady(), reached after animate() completes a render. A created canvas only proves renderer allocation. The other canvas is the decorative space field. Model loading has no deadline, and requestFrame/animate require loaded=true, document visible, and intersection in view. A pending model request or a first-frame scheduling stall therefore leaves the overlay visible indefinitely without a thrown error. Known thrown model/render errors previously replaced the spinner text; they did not provide the requested static illustration.

The exact stalled prerequisite in the user's cloud browser is not established by the reported canvas count and absent errors alone; no authenticated real session or real data was used to reproduce it. Browser cache bytes were not fetched from that session. The release source comparison above is definitive for the published/saved bundles.

The data path had a separate problem: it awaited all five table queries and then decisionAuthors before committing any results. One unrelated pending query could delay a successfully retrieved dossier indefinitely.

## v36 behavior

- Visual-only watchdog starts at mount and after software fallback initialization. After 8000ms without a first frame it hides/clears the loading overlay, invalidates pending model loads, stops/releases the renderer, and presents assets/brain-visual.svg with exactly: « Visuel 3D indisponible sur cet appareil ».
- Explicit model/render failures use the same static fallback. Late promises cannot replace it. Disposal clears timers; a successful first frame cancels the deadline.
- The fallback changes only the visual stage, not Promesse, Personas, Ton de la marque, Concurrents, questionnaire, or Informations classées.
- Brain data has its own loading state and explicit error + retry state. An error never renders the 3D viewport or static illustration as substitute data.
- Read-only queries have a 12000ms deadline. Each table is committed independently; decision-author lookup cannot hold up the dossier. Unrelated table/author completions do not remount the Brain visual. Stale refresh/account responses are ignored.
- Auth, backend configuration, roles, write methods and RLS are unchanged. No real accounts, clients, Brain documents or database policies were modified.
- Bundle and entrypoint cache keys updated for v36.

## Validation

Build and syntax checks passed. 89 automated tests passed, including stalled/successful/disposed visual lifecycle, late results, explicit model failure, read timeout/success/failure and Brain data error/loading/real field rendering.

Two browser checks used a separate LOCAL MOCK read-only harness with external connections blocked:
1. Hold both GLB fetches pending: initial loading is replaced by the static illustration and honest message. Promesse, Personas, Ton, Concurrents and Informations classées remain in the DOM. Screenshot fallback-proof.jpg.
2. Return an explicit brand_dossiers error: alert + Réessayer le chargement; zero visual viewports and zero static fallback images. Screenshot data-error-proof.jpg.

These are mock verification images, not real Koya records. No repeated screenshot loop was run. Real WebGL first-frame behavior on the user's device and real authenticated database reads remain unverified. v36 must remain saved without deployment.
