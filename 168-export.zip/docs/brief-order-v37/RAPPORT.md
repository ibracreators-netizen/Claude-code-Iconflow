# IconFlow Studio — ordre des Pages — version de travail v37

Enregistrée sans publication. Base de développement : v36 (commit c0c74de099b985660a204c824a73d65eac9ee00e), conservant les travaux v35/v36. La v34 publiée n’est pas déployée de nouveau, modifiée ou remplacée. Aucune requête à Supabase de production n’a été lancée pour ces tests ; aucune donnée réelle n’a été écrite. Aucune migration ni modification RLS.

## Ordre réel vérifié dans la v34

Version v34 résolue par Sites : commit `da27183aee551344b65a1c2a517e8123f9a94f69`.
Dans `dist/supabase-store.js`, `ScopedRepository.table` :

```js
const result=this.result(await this.sdk.from(table).select('*').eq('client_id',id).limit(200));
```

Aucun `.order()`, aucun tri `created_at` ou `id`. Dans `dist/connected-studio.js`, `briefs()` applique seulement des filtres : mois, statut non archivé et type du volet affiché. `filter()` puis `map()` conservent l’ordre du tableau du chargeur.
L’ordre est donc celui de la réponse Supabase, pas un ordre chronologique garanti. La séquence fournie par l’utilisateur est `04,05,02,03,06,10,07,08,01,09` : elle est utilisée dans les tests sans être codée en dur dans l’application.

La requête v34 est conservée. Le seul tri ajouté est stable : positions non NULL croissantes, puis NULL conservant leur ordre relatif de réception. Les égalités de position conservent aussi l’ordre de réception. Quand toutes les positions sont NULL, l’ordre est strictement inchangé. Sans ORDER BY, la base ne garantit pas le même ordre physique de réponse pour toujours ; aucun tri artificiel n’est ajouté pour tenter de le remplacer.

## Fichiers de production modifiés

- `dist/supabase-store.js` : comparateur stable partagé ; tri des résultats briefs pour tous les consommateurs ; méthode agence `reorderBriefs`.
- `dist/connected-studio.js` : rendu agence avec poignée et Monter/Descendre ; pointerdown/move/up/cancel, capture du pointeur et Échap ; déplacement vertical desktop et horizontal mobile, défilement aux bords ; ordre optimiste, restauration en cas d’erreur et annonce ; adaptateur local/mock explicitement activé par le contexte.
- `dist/connected-studio.css` : commandes, focus, cibles mobiles et retour visuel ; touch-action:none limité à la poignée.
- `dist/auth-gate.js` : raccordement à la session agence et au client actif ; cache-busting de l’import Store.
- `dist/index.html` : cache-busting des fichiers concernés et région aria-live persistante hors du contenu remplacé.

Fichiers de contrôle ajoutés : `tests/brief-order.test.mjs`, `tests/fixtures/brief-order.html`, ce dossier avec les captures et le résultat des tests. Le banc d’essai n’est pas inclus dans dist. Aucun élément de démonstration n’est ajouté à l’application.

## Écriture et limites

Le déplacement concerne exactement les pages visibles du volet, du mois et du client sélectionnés. Les autres types, mois et pages archivées sont exclus. Après un déplacement effectif, la liste complète visible reçoit 1..N ; seules les lignes dont la valeur change sont écrites :

```js
sdk.from('briefs').update({position})
  .eq('id', row.id).eq('client_id', client)
  .select('id,client_id,position').single()
```

Aucun titre, contenu, statut ou champ de validation n’est envoyé. Les numéros présents dans les titres restent identiques ; seul l’indice visuel de la liste change. Ni chargement ni rechargement ne déclenchent d’écriture. Les clients n’ont ni poignée ni commandes, et la méthode repository vérifie aussi le rôle agence. La session SDK et les RLS existantes restent l’autorité.

Les updates REST sont séquentiels, sans transaction SQL ajoutée. En cas d’échec après des updates déjà confirmés, le code tente de rétablir leurs anciennes positions, avec les mêmes filtres et la seule colonne position. L’écran revient à l’ordre précédent et affiche une erreur. Si cette compensation échoue, le message demande explicitement d’actualiser avant de réessayer ; l’atomicité distante ne peut pas être garantie sans changement serveur. Deux agences modifiant simultanément les mêmes pages ne disposent pas d’un verrou serveur.

La limite existante du chargeur (200 lignes par table/client) reste conservée. Si elle est atteinte, le réordonnancement est désactivé pour éviter de normaliser une liste potentiellement incomplète. Le mode local/mock est un adaptateur de test explicite (`ctx.mode`), sans nouvelle route de démo dans l’application ; il conserve les seules positions dans localStorage par client et par id.

## Vérifications effectuées

`npm run check` et `node --test tests/*.test.mjs` : 97 tests réussis, 0 échec.
Huit nouveaux tests couvrent l’ordre NULL exact malgré dates/titres divergents, les positions mixtes, les updates minimaux et les filtres, le premier classement 1..N, l’absence d’updates superflus, le refus client et des listes hors périmètre, la compensation d’erreur, le retour visuel et la persistance locale.

Contrôle navigateur sur banc isolé utilisant le vrai rendu et les vrais gestionnaires pointer du dist, données fictives seulement :

- Desktop : glisser `04` de la première à la troisième place ; résultat `05,02,04,03,06,10,07,08,01,09`. Rechargement : ordre conservé.
- 390px : cadre iframe d’exactement 390 CSS px, en continuité du classement desktop ; glisser horizontalement `05` de la première à la deuxième place ; résultat `02,05,04,03,06,10,07,08,01,09`. Rechargement : ordre conservé.
- Les captures sont des preuves du banc mock, pas des captures d’un compte connecté à la production. Aucun test tactile sur appareil physique ni test d’écriture distante/RLS réelle n’est revendiqué.

## Comment tester avec l’agence connectée

Ce protocole est à exécuter volontairement par l’agence sur la version de travail servie localement avec la configuration existante. Le Supabase configuré est la production : chaque déplacement confirmé écrit réellement des positions.

1. Ouvrir un client et un mois dans Briefs, puis le volet vidéo ou statique. Avant tout déplacement, vérifier l’ordre hérité si toutes les positions sont NULL.
2. Glisser par la poignée ; vérifier l’annonce de position, les titres inchangés et la page sélectionnée conservée. Recharger : vérifier le classement.
3. Déplacer une page d’une place avec les boutons Monter/Descendre au clavier (Tab puis Entrée/Espace). Vérifier l’annonce aria-live avec un lecteur d’écran.
4. À 390px, glisser par la poignée dans la liste horizontale ; faire défiler la liste et la page hors poignée pour vérifier l’absence d’interférence. Sur téléphone, vérifier avec un vrai doigt.
5. Dans l’inspecteur réseau, vérifier que seuls les PATCH nécessaires sont envoyés, avec `{position: entier}` et les filtres id/client_id. Un nouveau chargement seul ne doit envoyer aucun PATCH.
6. Couper le réseau avant un déplacement, vérifier l’ordre précédent et l’erreur. Réactiver le réseau et recharger avant de reprendre.
7. Ouvrir le même client en rôle client : classement identique, aucune poignée/commande et aucune écriture.
8. Changer de mois, de volet et de client : vérifier que les autres listes gardent leurs positions. Vérifier aussi les pages archivées hors cible.

## Non-régression

- [x] Aucun déploiement/publish ; version publiée v34 conservée.
- [x] Aucun accès ni écriture de test sur Supabase production.
- [x] Aucune migration, modification RLS, suppression ou changement de statut.
- [x] Titres/contenus/validation préservés dans les payloads et les tests.
- [x] Ordre NULL v34 conservé et couvert par la séquence demandée.
- [x] Vue client sans commande ; garde agence dans UI et repository.
- [x] Autres mois/types/clients et corbeille exclus du déplacement.
- [x] Aucun exemple de démonstration réintroduit dans dist.
- [x] Édition, création, corbeille/restauration, validations briefs/livrables, avatars et Brain : suite existante réussie.
- [x] Build livré : JavaScript statique directement modifié ; bundles 3D/éditeur existants conservés, aucun rebuild nécessaire.
- [ ] Persistance Supabase réelle, RLS réelle et tactile physique : à vérifier volontairement par l’agence, pas automatisés sur la production.

## Captures

| Vue | Avant déplacement | Après déplacement | Après rechargement |
|---|---|---|---|
| Desktop | ![](iconflow-desktop-before.jpg) | ![](iconflow-desktop-after.jpg) | ![](iconflow-desktop-reloaded.jpg) |
| 390px | ![](iconflow-mobile-before.jpg) | ![](iconflow-mobile-after.jpg) | ![](iconflow-mobile-reloaded.jpg) |
